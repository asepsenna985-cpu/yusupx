/* NAME : RizzPiw */

process.on('unhandledRejection', console.error)
process.on('uncaughtException', console.error)

for (const signal of ['SIGINT', 'SIGTERM']) {
process.once(signal, () => {
try { global.__absenState?.cronTask?.stop?.(); } catch {}
if (global.__absenState) global.__absenState.cronTask = null;
process.exit(0);
});
}

require('./settings');
const fs = require('fs');
const path = require('path');
const util = require('util');
const chalk = require('chalk');
const moment = require('moment-timezone');
const cron = require('node-cron');

//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\\
// PATH & DATABASE
const DB_PATH = './database/absen.json';
const MEDIA_DIR = './database/absen_media';
const MEDIA_MAX_AGE_DAYS = 14;

if (!fs.existsSync('./database')) fs.mkdirSync('./database', { recursive: true });
if (!fs.existsSync(MEDIA_DIR)) fs.mkdirSync(MEDIA_DIR, { recursive: true });
if (!fs.existsSync(DB_PATH)) fs.writeFileSync(DB_PATH, JSON.stringify({ absen: [], jumat: [] }, null, 2));

//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\\
// GLOBAL STATE
if (!global.__absenState) {
global.__absenState = {
cronTask: null,
client: null,
running: false,
lastCleanupDay: null
};
}
const STATE = global.__absenState;

//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\\
// TIMEZONE
const TZ_MAP = {
WIB: 'Asia/Jakarta',
WIT: 'Asia/Jayapura',
WITA: 'Asia/Makassar'
};

//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\\
// DB
function readDB() {
try {
const raw = fs.readFileSync(DB_PATH, 'utf-8');
const parsed = JSON.parse(raw);
if (!Array.isArray(parsed.absen)) parsed.absen = [];
if (!Array.isArray(parsed.jumat)) parsed.jumat = [];

// Dedupe by grup + jam + waktu
const seen = new Set();
const cleaned = [];
for (const a of parsed.absen) {
if (!a || !a.grup || !a.jam) continue;
const key = `${a.grup}|${a.jam}|${a.waktu}`;
if (seen.has(key)) continue;
seen.add(key);
cleaned.push(a);
}
parsed.absen = cleaned;

const seenJ = new Set();
const cleanedJ = [];
for (const j of parsed.jumat) {
if (!j || !j.grup) continue;
if (seenJ.has(j.grup)) continue;
seenJ.add(j.grup);
cleanedJ.push(j);
}
parsed.jumat = cleanedJ;

return parsed;
} catch {
return { absen: [], jumat: [] };
}
}

function writeDB(data) {
const tmp = DB_PATH + '.tmp';
const json = JSON.stringify(data, null, 2);
try {
fs.writeFileSync(tmp, json);
fs.renameSync(tmp, DB_PATH);
} catch {
try { fs.writeFileSync(DB_PATH, json); } catch {}
}
}

function getOwners() {
const owners = global.owner || [];
if (!Array.isArray(owners)) return [];
return owners.map(v => String(v).replace(/[^0-9]/g, '')).filter(Boolean).map(n => n + '@s.whatsapp.net');
}

function jamSudahLewat(jam, waktu) {
const tz = TZ_MAP[waktu];
if (!tz) return { lewat: false, currentJam: '-' };
const now = moment().tz(tz);
const currentJam = now.format('HH:mm');
return { lewat: currentJam > jam, currentJam };
}

async function getGroupMentions(client, grup) {
try {
const meta = await client.groupMetadata(grup);
return (meta.participants || []).map(p => p.id).filter(Boolean);
} catch (e) {
console.error(chalk.red(`[ABSEN] Gagal ambil participant ${grup}: ${e.message}`));
return [];
}
}

function getExtFromMime(mime) {
if (!mime) return 'bin';
const m = String(mime).toLowerCase();
if (m.includes('jpeg') || m.includes('jpg')) return 'jpg';
if (m.includes('png')) return 'png';
if (m.includes('webp')) return 'webp';
if (m.includes('gif')) return 'gif';
if (m.includes('mp4')) return 'mp4';
if (m.includes('3gp')) return '3gp';
if (m.includes('mpeg') || m.includes('mp3')) return 'mp3';
if (m.includes('ogg')) return 'ogg';
if (m.includes('wav')) return 'wav';
if (m.includes('pdf')) return 'pdf';
return 'bin';
}

function getMediaSource(m, quotedMime) {
if (m.quoted && /image|video|audio|sticker/i.test(quotedMime)) {
return { source: m.quoted, mime: quotedMime };
}
const directTypes = ['imageMessage', 'videoMessage', 'audioMessage', 'stickerMessage'];
if (directTypes.includes(m.mtype) && m.message && m.message[m.mtype]) {
const content = m.message[m.mtype];
return { source: content, mime: content.mimetype || '' };
}
return { source: null, mime: '' };
}

function parseJamWaktu(input) {
if (!input) return null;
const parts = String(input).trim().split(/\s+/);
if (parts.length < 2) return null;

const waktu = parts[parts.length - 1].toUpperCase();
const jamRaw = parts.slice(0, parts.length - 1).join('');
if (!TZ_MAP[waktu]) return null;

let jam, menit;
if (jamRaw.includes(':') || jamRaw.includes('.')) {
const arr = jamRaw.split(/[:.]/);
jam = parseInt(arr[0], 10);
menit = parseInt(arr[1] || '0', 10);
} else {
jam = parseInt(jamRaw, 10);
menit = 0;
}
if (isNaN(jam) || jam < 0 || jam > 23) return null;
if (isNaN(menit) || menit < 0 || menit > 59) return null;

return { jam: `${String(jam).padStart(2, '0')}:${String(menit).padStart(2, '0')}`, waktu };
}

//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\\
// FLAG PARSER

function extractFlags(teks) {
let noMention = false;
if (/(^|\s)--nomention(\s|$)/i.test(teks)) noMention = true;

const cleanText = teks
.replace(/(^|\s)--nomention(\s|$)/gi, ' ')
.replace(/[ \t]{2,}/g, ' ')
.trim();

return { noMention, cleanText };
}

//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\\
// PARSER FORMAT: idgrup|jam WIB|teks

function parseSetabsenInput(text) {
const parts = text.split('|').map(s => s.trim());
if (parts.length < 3) return null;

const grup = parts[0];
const jamWaktuRaw = parts[1];
const teksRaw = parts.slice(2).join('|').trim();

if (!grup.endsWith('@g.us')) return { error: '❌ ID grup harus diakhiri *@g.us*.' };

const parsed = parseJamWaktu(jamWaktuRaw);
if (!parsed) return { error: `❌ Format jam/waktu salah!\nContoh: *10 WIB*, *10:30 WITA*` };

if (!teksRaw) return { error: '❌ Teks pengumuman tidak boleh kosong.' };

const flags = extractFlags(teksRaw);
if (!flags.cleanText) return { error: '❌ Teks pengumuman tidak boleh kosong.' };

return {
grup,
jam: parsed.jam,
waktu: parsed.waktu,
teks: flags.cleanText,
noMention: flags.noMention
};
}

//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\\
// SEND

async function sendAbsen(client, item, opts = {}) {
const grup = item.grup;
const teks = item.teks || '';
const noMention = opts.noMention !== undefined ? opts.noMention : !!item.noMention;

let mentions = [];
if (!noMention) {
mentions = opts.mentions !== undefined ? opts.mentions : await getGroupMentions(client, grup);
}
const mentionOpt = noMention ? {} : { mentions };

if (item.media && fs.existsSync(item.media)) {
const buffer = fs.readFileSync(item.media);
const mime = String(item.mimetype || '').toLowerCase();

if (mime.startsWith('image')) {
await client.sendMessage(grup, { image: buffer, caption: teks, ...mentionOpt });
} else if (mime.startsWith('video')) {
await client.sendMessage(grup, { video: buffer, caption: teks, ...mentionOpt });
} else if (mime.startsWith('audio')) {
await client.sendMessage(grup, { audio: buffer, mimetype: item.mimetype || 'audio/mpeg', ptt: false });
if (teks) await client.sendMessage(grup, { text: teks, ...mentionOpt });
} else {
await client.sendMessage(grup, {
document: buffer,
mimetype: item.mimetype || 'application/octet-stream',
fileName: path.basename(item.media),
caption: teks
});
}
} else {
await client.sendMessage(grup, { text: teks, ...mentionOpt });
}
}

//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\\
// CRON

function startCron(client) {
STATE.client = client;
if (STATE.cronTask) return;

STATE.cronTask = cron.schedule('* * * * *', async () => {
if (STATE.running) return;
STATE.running = true;
try {
const activeClient = STATE.client;
if (!activeClient) return;

const db = readDB();

//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\\
// ABSEN HARIAN
//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\\
for (const item of db.absen) {
if (!item || item.status === 'off' || !item.jam) continue;

const tz = TZ_MAP[item.waktu];
if (!tz) continue;

const now = moment().tz(tz);
const todayKey = now.format('YYYY-MM-DD');
const currentJam = now.format('HH:mm');

if (currentJam !== item.jam) continue;

if (item.dayKey === todayKey && item.lastSentAt) continue;

const freshDb = readDB();
const idx = freshDb.absen.findIndex(a => a.grup === item.grup && a.jam === item.jam && a.waktu === item.waktu);
if (idx < 0) continue;
const fi = freshDb.absen[idx];

if (fi.dayKey === todayKey && fi.lastSentAt) continue;

fi.dayKey = todayKey;
fi.lastSentAt = `${todayKey} ${currentJam} ${fi.waktu}`;
fi.lastSentAtMs = Date.now();
fi.history = [...(fi.history || []).slice(-4), `${todayKey} ${currentJam} ${fi.waktu}`];
writeDB(freshDb);

try {
await sendAbsen(activeClient, fi);
console.log(chalk.green(
`[ABSEN] ✔ Terkirim → ${fi.grup} @ ${currentJam} ${fi.waktu}`
));
} catch (e) {
console.error(chalk.red(
`[ABSEN] ✘ Gagal kirim → ${fi.grup}: ${e.message}`
));
const rbDb = readDB();
const rbIdx = rbDb.absen.findIndex(a => a.grup === item.grup && a.jam === item.jam && a.waktu === item.waktu);
if (rbIdx >= 0) {
rbDb.absen[rbIdx].dayKey = null;
rbDb.absen[rbIdx].lastSentAt = null;
rbDb.absen[rbIdx].lastSentAtMs = null;
writeDB(rbDb);
}
}
}

//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\\
// NOTIF KHUSUS JUMAT
//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\\
if (Array.isArray(db.jumat) && db.jumat.length > 0) {
for (const jItem of db.jumat) {
if (!jItem || jItem.status === 'off') continue;

const tz = TZ_MAP[jItem.waktu];
if (!tz) continue;

const now = moment().tz(tz);
const todayKey = now.format('YYYY-MM-DD');
const currentJam = now.format('HH:mm');

if (now.day() !== 5) continue;
if (currentJam !== jItem.jam) continue;
if (jItem.dayKey === todayKey && jItem.lastSentAt) continue;

const freshDb = readDB();
const jIdx = freshDb.jumat.findIndex(j => j.grup === jItem.grup);
if (jIdx < 0) continue;
const fj = freshDb.jumat[jIdx];

if (fj.dayKey === todayKey && fj.lastSentAt) continue;

fj.dayKey = todayKey;
fj.lastSentAt = `${todayKey} ${currentJam} ${fj.waktu} (Jumat)`;
fj.lastSentAtMs = Date.now();
writeDB(freshDb);

try {
await sendAbsen(activeClient, fj);
console.log(chalk.magenta(
`[ABSEN] 🕌 Notif JUMAT → ${fj.grup} @ ${currentJam} ${fj.waktu}`
));
} catch (e) {
console.error(chalk.red(
`[ABSEN] ✘ Notif Jumat gagal → ${fj.grup}: ${e.message}`
));
const rbDb = readDB();
const rbIdx = rbDb.jumat.findIndex(j => j.grup === jItem.grup);
if (rbIdx >= 0) {
rbDb.jumat[rbIdx].dayKey = null;
rbDb.jumat[rbIdx].lastSentAt = null;
writeDB(rbDb);
}
}
}
}

const todayKey = moment().tz('Asia/Jakarta').format('YYYY-MM-DD');
if (STATE.lastCleanupDay !== todayKey) {
STATE.lastCleanupDay = todayKey;
cleanupOldMedia(db);
}
} catch (e) {
console.error(chalk.red(`[ABSEN] Cron error: ${e.message}`));
} finally {
STATE.running = false;
}
}, { timezone: 'Asia/Jakarta' });

console.log(chalk.green('[ABSEN] Cron aktif — mode simple (1× kirim).'));
}

function cleanupOldMedia(db) {
try {
const used = new Set();
for (const a of (db.absen || [])) if (a.media) used.add(a.media);
for (const j of (db.jumat || [])) if (j.media) used.add(j.media);

const files = fs.readdirSync(MEDIA_DIR);
const cutoff = Date.now() - MEDIA_MAX_AGE_DAYS * 24 * 60 * 60 * 1000;
let removed = 0;
for (const f of files) {
const full = path.join(MEDIA_DIR, f);
if (used.has(full)) continue;
try {
const st = fs.statSync(full);
if (st.mtimeMs < cutoff) { fs.unlinkSync(full); removed++; }
} catch {}
}
if (removed) console.log(chalk.gray(`[ABSEN] Cleanup: ${removed} media lama dihapus.`));
} catch {}
}

//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\\
// MAIN HANDLER
module.exports = RizzPiw = async (RizzPiw, m, chatUpdate, mek, store) => {
try {
startCron(RizzPiw);

const body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : '';

const prefix = /^[°#*+,.?=''():√%!¢£¥€π¤ΠΦ_&`™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°#*+,.?=''():√%¢£¥€π¤ΠΦ_&!`™©®Δ^βα¦|/\\©^]/gi) : '.';

const isCmd = body.startsWith(prefix);
const from = m.key.remoteJid;
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase();
const args = body.trim().split(/ +/).slice(1);
const text = args.join(' ');
const pushname = m.pushName || 'No Name';
const sender = m.sender;
const isPrivate = !m.isGroup;
const quoted = m.quoted ? m.quoted : m;
const mime = (quoted.msg || quoted).mimetype || '';

const isCreator = getOwners().includes(sender);

if (m.message && isCmd) {
console.log(chalk.cyan.bold(`╭─[ COMMAND ]`));
console.log(chalk.cyan('│') + ` ${chalk.green(pushname)} (${sender.split('@')[0]})`);
console.log(chalk.cyan('│') + ` ${chalk.yellow(command)} ${chalk.white(text)}`);
console.log(chalk.cyan.bold('╰────────────'));
}

const fkontak = {
key: {
fromMe: false,
participant: `0@s.whatsapp.net`,
...(from ? { remoteJid: 'status@broadcast' } : {})
},
message: {
'contactMessage': {
'displayName': `Developer Asep Yusup`,
'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;AsepYusup,;;;\nFN:${pushname},\nitem1.TEL;waid=${sender.split('@')[0]}:${sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
}
}
};

const reply = (teks) => RizzPiw.sendMessage(from, { text: teks }, { quoted: fkontak });

switch (command) {

//━━━━━━━━━━━━━━━[ MENU ]━━━━━━━━━━━━━━━\\
case 'menu': {
if (!isPrivate) return
const menu = `「 *ABSEN BOT - ${ownerName}* 」

Bot pengingat otomatis untuk grup.
*1× set = 1× kirim aja, gak ada spam* 🎯

━━━━━━━━━━━━━━━━━━
📌 *FORMAT SETTING*
━━━━━━━━━━━━━━━━━━
*${prefix}setabsen* idgrup|jam WIB|teks

• Bisa bikin sampai *${MAX_PENGINGAT}× pengingat* per grup
• Tiap pengingat dikirim *1× aja* pas jam tiba

━━━━━━━━━━━━━━━━━━
📝 *CONTOH*
━━━━━━━━━━━━━━━━━━
${prefix}setabsen 123@g.us|07:00 WIB|Absen masuk
${prefix}setabsen 123@g.us|10:00 WIB|CO barang
${prefix}setabsen 123@g.us|17:00 WIB|Pulang kerja

*Hasil di grup:*
• 07:00 → Absen masuk
• 10:00 → CO barang
• 17:00 → Pulang kerja

━━━━━━━━━━━━━━━━━━
🕌 *NOTIF KHUSUS JUMAT*
━━━━━━━━━━━━━━━━━━
▸ *${prefix}setjumat* idgrup|jam WIB|teks
▸ *${prefix}deljumat* idgrup

Contoh:
${prefix}setjumat 123@g.us|11:30 WIB|Sholat Jumat!

━━━━━━━━━━━━━━━━━━
🔕 *MATIKAN SEMENTARA*
━━━━━━━━━━━━━━━━━━
▸ *${prefix}off-jam* idgrup|jam WIB
 ↳ Matiin 1 jam spesifik (data tetap ada)
▸ *${prefix}on-jam* idgrup|jam WIB
 ↳ Nyalain 1 jam spesifik
▸ *${prefix}off-absen* idgrup
 ↳ Matiin semua jam di grup
▸ *${prefix}on-absen* idgrup
 ↳ Nyalain semua jam di grup

━━━━━━━━━━━━━━━━━━
🗑️ *HAPUS PERMANEN*
━━━━━━━━━━━━━━━━━━
▸ *${prefix}resetabsen* idgrup|jam WIB → hapus 1
▸ *${prefix}resetabsen* idgrup → hapus SEMUA

━━━━━━━━━━━━━━━━━━
⚙️ *FLAG OPSIONAL*
━━━━━━━━━━━━━━━━━━
• *--nomention* → jangan tag semua member

Contoh:
${prefix}setabsen 123@g.us|07:00 WIB|Absen masuk --nomention

━━━━━━━━━━━━━━━━━━
🛠️ *COMMAND LAIN*
━━━━━━━━━━━━━━━━━━
▸ *${prefix}up-set* idgrup|jam WIB|teks
▸ *${prefix}listabsen* → lihat pengingat
▸ *${prefix}listgc*→ lihat semua grup bot
▸ *${prefix}statabsen* → statistik
▸ *${prefix}testabsen* idgrup|jam
▸ *${prefix}cekid* → lihat ID grup

━━━━━━━━━━━━━━━━━━
©  ${ownerName} Absen Bot`;
await RizzPiw.sendMessage(from, { text: menu }, { quoted: fkontak });
}
break;

//━━━━━━━━━━━━━━━[ CEK ID GRUP ]━━━━━━━━━━━━━━━\\
case 'cekid': case 'idgc': {
if (!m.isGroup) return reply('Fitur ini hanya bisa dipakai di dalam grup.');
reply(`ID Grup ini:\n\n*${from}*`);
}
break;

//━━━━━━━━━━━━━━━[ LIST GRUP BOT ]━━━━━━━━━━━━━━━\\
case 'listgc': case 'listgrup': {
if (!isPrivate) return reply('⚠️ Fitur setting absen *hanya bisa di private chat*.\n\nChat bot pribadi dulu ya!');
if (!isCreator) return reply('❌ Fitur ini khusus Owner.');

try {
const groupsData = await RizzPiw.groupFetchAllParticipating().catch(() => ({}));
const groups = Object.values(groupsData || {});

if (!groups.length) return reply('Bot tidak terdaftar di grup mana pun.');

let listgc = `⬣ Total Group: ${groups.length} Group\n\n`;
groups.forEach((group, index) => {
listgc += `╭───── Group ${index + 1} ─────\n`;
listgc += `⬡ Nama: ${group.subject || '-'}\n`;
listgc += `⬡ ID: ${group.id}\n`;
listgc += `⬡ Member: ${(group.participants || []).length}\n`;
listgc += `╰──────────────────────\n\n`;
});

reply(listgc);
} catch (error) {
console.error('Terjadi kesalahan:', error);
reply('Terjadi kesalahan saat mengambil daftar grup. Coba lagi nanti.');
}
}
break;

//━━━━━━━━━━━━━━━[ SET ABSEN ]━━━━━━━━━━━━━━━\\
case 'setabsen': case 'addabsen': case 'absen': {
if (!isPrivate) return reply('⚠️ Fitur setting absen *hanya bisa di private chat*.\n\nChat bot pribadi dulu ya!');
if (!isCreator) return reply('❌ Fitur ini khusus Owner.');
if (!text) return reply(`Format:\n${prefix}setabsen idgrup|jam WIB|teks\n\nContoh:\n${prefix}setabsen 123@g.us|07:00 WIB|Absen masuk`);

const parsedInput = parseSetabsenInput(text);
if (!parsedInput) return reply(`❌ Format salah!\n\nGunakan:\n${prefix + command} idgrup|jam WIB|teks`);
if (parsedInput.error) return reply(parsedInput.error);

const { grup, jam, waktu, teks, noMention } = parsedInput;

const db = readDB();

const exist = db.absen.find(a => a.grup === grup && a.jam === jam && a.waktu === waktu);
if (exist) {
return reply(`⚠️ Grup ini sudah punya pengingat di jam *${jam} ${waktu}*.\n\nPakai jam berbeda, atau hapus dulu pakai *${prefix}resetabsen ${grup}|${jam} ${waktu}*.`);
}

const count = db.absen.filter(a => a.grup === grup).length;
if (count >= MAX_PENGINGAT) {
return reply(`⚠️ Grup ini sudah punya *${MAX_PENGINGAT} pengingat* (batas maksimal).\n\nHapus salah satu dulu pakai *${prefix}resetabsen ${grup}|jam*.`);
}

try {
const meta = await RizzPiw.groupMetadata(grup);
if (!meta) return reply('❌ Bot tidak ada di grup tersebut atau ID salah.');
} catch {
return reply('❌ Gagal akses grup. Pastikan bot sudah masuk ke grup tersebut.');
}

let mediaPath = null;
let mediaMime = null;

const mediaInfo = getMediaSource(m, mime);
if (mediaInfo.source) {
await reply('📥 Mengunduh media...');
try {
const buffer = await RizzPiw.downloadMediaMessage(mediaInfo.source);
const ext = getExtFromMime(mediaInfo.mime);
const filename = `${grup.replace(/[^0-9]/g, '')}_${jam.replace(':', '')}_${Date.now()}.${ext}`;
mediaPath = path.join(MEDIA_DIR, filename);
fs.writeFileSync(mediaPath, buffer);
mediaMime = mediaInfo.mime;
} catch (e) {
console.error('Gagal download media:', e);
return reply(`❌ Gagal mengunduh media: ${e.message}`);
}
}

db.absen.push({
grup,
jam,
waktu,
teks,
media: mediaPath,
mimetype: mediaMime,
noMention,
status: 'on',
createdAt: new Date().toISOString(),
dayKey: null,
lastSentAt: null,
lastSentAtMs: null,
history: []
});
writeDB(db);

let grupName = grup;
try { grupName = (await RizzPiw.groupMetadata(grup)).subject; } catch {}

const totalGrup = db.absen.filter(a => a.grup === grup).length;

reply(`✅ *Pengingat berhasil dibuat!*

📌 Grup : ${grupName}
🆔 ID : ${grup}
⏰ Jam : ${jam} ${waktu}
📝 Teks : ${teks}
${mediaPath ? '🖼️ Media : Ada ✔️' : '🖼️ Media : Tidak ada'}
${noMention ? '🔕 Mention : OFF' : '🔔 Mention : ON (semua member)'}

📊 Total pengingat grup ini : *${totalGrup}/${MAX_PENGINGAT}*

Bot akan kirim *1× aja* pas jam tersebut.`);

const cekLewat = jamSudahLewat(jam, waktu);
if (cekLewat.lewat) {
await reply(`⏰ *JAM ${jam} ${waktu} telah lewat* (sekarang ${cekLewat.currentJam} ${waktu}).\nPengingat ini akan mulai besok.`);
}
}
break;

//━━━━━━━━━━━━━━━[ UPDATE ]━━━━━━━━━━━━━━━\\
case 'up-set': case 'upset': case 'updateabsen': case 'updateset': {
if (!isPrivate) return reply('⚠️ Fitur ini hanya bisa di private chat.');
if (!isCreator) return reply('❌ Fitur ini khusus Owner.');
if (!text) return reply(`Format:\n${prefix + command} idgrup|jam WIB|teks`);

const parsedInput = parseSetabsenInput(text);
if (!parsedInput) return reply(`❌ Format salah!\n\nGunakan:\n${prefix + command} idgrup|jam WIB|teks`);
if (parsedInput.error) return reply(parsedInput.error);

const { grup, jam, waktu, teks, noMention } = parsedInput;

const db = readDB();
const idx = db.absen.findIndex(a => a.grup === grup && a.jam === jam && a.waktu === waktu);
if (idx === -1) {
const list = db.absen.filter(a => a.grup === grup).map(a => `• ${a.jam} ${a.waktu} → ${a.teks}`).join('\n');
return reply(`❌ Tidak ada pengingat jam *${jam} ${waktu}* di grup *${grup}*.\n\n📋 Pengingat yang ada:\n${list || '(kosong)'}\n\nGunakan *${prefix}setabsen* untuk membuat baru.`);
}

let mediaPath = db.absen[idx].media;
let mediaMime = db.absen[idx].mimetype;

const mediaInfo = getMediaSource(m, mime);
if (mediaInfo.source) {
await reply('📥 Mengunduh media baru...');
try {
if (mediaPath && fs.existsSync(mediaPath)) {
try { fs.unlinkSync(mediaPath); } catch {}
}
const buffer = await RizzPiw.downloadMediaMessage(mediaInfo.source);
const ext = getExtFromMime(mediaInfo.mime);
const filename = `${grup.replace(/[^0-9]/g, '')}_${jam.replace(':', '')}_${Date.now()}.${ext}`;
mediaPath = path.join(MEDIA_DIR, filename);
fs.writeFileSync(mediaPath, buffer);
mediaMime = mediaInfo.mime;
} catch (e) {
console.error(e);
return reply(`❌ Gagal download media: ${e.message}`);
}
}

Object.assign(db.absen[idx], {
teks,
media: mediaPath,
mimetype: mediaMime,
noMention,
updatedAt: new Date().toISOString(),
dayKey: null,
lastSentAt: null,
lastSentAtMs: null
});
writeDB(db);

let grupName = grup;
try { grupName = (await RizzPiw.groupMetadata(grup)).subject; } catch {}

reply(`✅ *Pengingat berhasil diupdate!*

📌 Grup : ${grupName}
⏰ Jam : ${jam} ${waktu}
📝 Teks : ${teks}
${mediaPath && fs.existsSync(mediaPath) ? '🖼️ Media : Ada ✔️' : '🖼️ Media : Tidak ada'}
${noMention ? '🔕 Mention : OFF' : '🔔 Mention : ON'}`);
}
break;

//━━━━━━━━━━━━━━━[ OFF-JAM (matikan 1 jam spesifik) ]━━━━━━━━━━━━━━━\\
case 'off-jam': case 'offjam': {
if (!isPrivate) return reply('⚠️ Fitur ini hanya bisa di private chat.');
if (!isCreator) return reply('❌ Fitur ini khusus Owner.');
if (!text) return reply(`Format:\n${prefix}off-jam idgrup|jam WIB\n\nContoh:\n${prefix}off-jam 123@g.us|18:00 WIB\n\nℹ️ Cuma matiin 1 jam spesifik. Data tetap ada.`);

const parts = text.split('|').map(s => s.trim());
const grup = parts[0];
if (!grup.endsWith('@g.us')) return reply('❌ ID grup harus diakhiri *@g.us*.');

const parsed = parseJamWaktu(parts[1]);
if (!parsed) return reply(`❌ Format jam salah!\nContoh: *18:00 WIB*`);

const db = readDB();
const idx = db.absen.findIndex(a => a.grup === grup && a.jam === parsed.jam && a.waktu === parsed.waktu);
if (idx === -1) {
const list = db.absen.filter(a => a.grup === grup).map(a => `• ${a.jam} ${a.waktu} → ${a.teks}`).join('\n');
return reply(`❌ Tidak ada pengingat jam *${parsed.jam} ${parsed.waktu}* di grup *${grup}*.\n\n📋 Yang ada:\n${list || '(kosong)'}`);
}

if (db.absen[idx].status === 'off') {
return reply(`ℹ️ Pengingat jam *${parsed.jam} ${parsed.waktu}* udah dalam keadaan OFF.`);
}

db.absen[idx].status = 'off';
writeDB(db);

let grupName = grup;
try { grupName = (await RizzPiw.groupMetadata(grup)).subject; } catch {}

reply(`🔕 *Pengingat dimatikan sementara!*

📌 Grup : ${grupName}
⏰ Jam : ${parsed.jam} ${parsed.waktu}
📝 ${db.absen[idx].teks}

Untuk nyalain: *${prefix}on-jam ${grup}|${parsed.jam} ${parsed.waktu}*`);
}
break;

//━━━━━━━━━━━━━━━[ ON-JAM (nyalakan 1 jam spesifik) ]━━━━━━━━━━━━━━━\\
case 'on-jam': case 'onjam': {
if (!isPrivate) return reply('⚠️ Fitur ini hanya bisa di private chat.');
if (!isCreator) return reply('❌ Fitur ini khusus Owner.');
if (!text) return reply(`Format:\n${prefix}on-jam idgrup|jam WIB\n\nContoh:\n${prefix}on-jam 123@g.us|18:00 WIB`);

const parts = text.split('|').map(s => s.trim());
const grup = parts[0];
if (!grup.endsWith('@g.us')) return reply('❌ ID grup harus diakhiri *@g.us*.');

const parsed = parseJamWaktu(parts[1]);
if (!parsed) return reply(`❌ Format jam salah!\nContoh: *18:00 WIB*`);

const db = readDB();
const idx = db.absen.findIndex(a => a.grup === grup && a.jam === parsed.jam && a.waktu === parsed.waktu);
if (idx === -1) {
const list = db.absen.filter(a => a.grup === grup).map(a => `• ${a.jam} ${a.waktu} → ${a.teks}`).join('\n');
return reply(`❌ Tidak ada pengingat jam *${parsed.jam} ${parsed.waktu}* di grup *${grup}*.\n\n📋 Yang ada:\n${list || '(kosong)'}`);
}

if (db.absen[idx].status === 'on') {
return reply(`ℹ️ Pengingat jam *${parsed.jam} ${parsed.waktu}* udah dalam keadaan ON.`);
}

db.absen[idx].status = 'on';
db.absen[idx].dayKey = null;
db.absen[idx].lastSentAt = null;
db.absen[idx].lastSentAtMs = null;
writeDB(db);

let grupName = grup;
try { grupName = (await RizzPiw.groupMetadata(grup)).subject; } catch {}

reply(`🔔 *Pengingat dinyalakan!*

📌 Grup : ${grupName}
⏰ Jam : ${parsed.jam} ${parsed.waktu}
📝 ${db.absen[idx].teks}

Pengingat akan aktif lagi sesuai jadwal.`);
}
break;

//━━━━━━━━━━━━━━━[ OFF-ABSEN (matikan semua jam di grup) ]━━━━━━━━━━━━━━━\\
case 'off-absen': case 'offabsen': case 'stopabsen': {
if (!isPrivate) return reply('⚠️ Fitur ini hanya bisa di private chat.');
if (!isCreator) return reply('❌ Fitur ini khusus Owner.');
if (!text) return reply(`Format:\n${prefix}off-absen idgrup\n\nContoh:\n${prefix}off-absen 123@g.us\n\nℹ️ Matiin SEMUA pengingat di grup ini.`);

const grup = text.trim().split('|')[0].trim();
if (!grup.endsWith('@g.us')) return reply('❌ ID grup harus diakhiri *@g.us*.');

const db = readDB();
const items = db.absen.filter(a => a.grup === grup);
if (items.length === 0) return reply(`❌ Tidak ada pengingat di grup *${grup}*.`);

let count = 0;
for (const t of items) {
const idx = db.absen.findIndex(a => a.grup === t.grup && a.jam === t.jam && a.waktu === t.waktu);
if (idx >= 0 && db.absen[idx].status !== 'off') {
db.absen[idx].status = 'off';
count++;
}
}
writeDB(db);

let grupName = grup;
try { grupName = (await RizzPiw.groupMetadata(grup)).subject; } catch {}

reply(`🔕 *Semua pengingat dimatikan!*

📌 Grup : ${grupName}
📊 Dimatikan : ${count} pengingat

Untuk nyalain semua: *${prefix}on-absen ${grup}*`);
}
break;

//━━━━━━━━━━━━━━━[ ON-ABSEN (nyalakan semua jam di grup) ]━━━━━━━━━━━━━━━\\
case 'on-absen': case 'onabsen': case 'startabsen': {
if (!isPrivate) return reply('⚠️ Fitur ini hanya bisa di private chat.');
if (!isCreator) return reply('❌ Fitur ini khusus Owner.');
if (!text) return reply(`Format:\n${prefix}on-absen idgrup\n\nContoh:\n${prefix}on-absen 123@g.us`);

const grup = text.trim().split('|')[0].trim();
if (!grup.endsWith('@g.us')) return reply('❌ ID grup harus diakhiri *@g.us*.');

const db = readDB();
const items = db.absen.filter(a => a.grup === grup);
if (items.length === 0) return reply(`❌ Tidak ada pengingat di grup *${grup}*.`);

let count = 0;
for (const t of items) {
const idx = db.absen.findIndex(a => a.grup === t.grup && a.jam === t.jam && a.waktu === t.waktu);
if (idx >= 0 && db.absen[idx].status !== 'on') {
db.absen[idx].status = 'on';
db.absen[idx].dayKey = null;
db.absen[idx].lastSentAt = null;
db.absen[idx].lastSentAtMs = null;
count++;
}
}
writeDB(db);

let grupName = grup;
try { grupName = (await RizzPiw.groupMetadata(grup)).subject; } catch {}

reply(`🔔 *Semua pengingat dinyalakan!*

📌 Grup : ${grupName}
📊 Dinyalakan : ${count} pengingat

Semua pengingat akan aktif kembali sesuai jadwal.`);
}
break;

//━━━━━━━━━━━━━━━[ RESETABsen (HAPUS permanen) ]━━━━━━━━━━━━━━━\\
case 'resetabsen': case 'delabsen': case 'hapusabsen': {
if (!isPrivate) return reply('⚠️ Fitur ini hanya bisa di private chat.');
if (!isCreator) return reply('❌ Fitur ini khusus Owner.');
if (!text) return reply(`Format:\n${prefix}resetabsen idgrup|jam WIB→ HAPUS 1 pengingat\n${prefix}resetabsen idgrup→ HAPUS SEMUA\n\n⚠️ Data akan dihapus permanen. Untuk cuma matiin sementara, pakai *${prefix}off-jam* atau *${prefix}off-absen*.`);

const raw = text.trim();
const parts = raw.split('|').map(s => s.trim());
const grup = parts[0];

if (!grup.endsWith('@g.us')) return reply('❌ ID grup harus diakhiri *@g.us*.');

const db = readDB();

if (parts.length === 1) {
const items = db.absen.filter(a => a.grup === grup);
if (items.length === 0) return reply(`❌ Tidak ada pengingat di grup *${grup}*.`);

for (const it of items) {
if (it.media && fs.existsSync(it.media)) {
try { fs.unlinkSync(it.media); } catch {}
}
}
db.absen = db.absen.filter(a => a.grup !== grup);
writeDB(db);
return reply(`✅ *${items.length} pengingat* grup *${grup}* berhasil DIHAPUS PERMANEN.`);
}

const parsed = parseJamWaktu(parts[1]);
if (!parsed) return reply(`❌ Format jam salah!\nContoh: *resetabsen 123@g.us|18:00 WIB*`);

const idx = db.absen.findIndex(a => a.grup === grup && a.jam === parsed.jam && a.waktu === parsed.waktu);
if (idx === -1) {
const list = db.absen.filter(a => a.grup === grup).map(a => `• ${a.jam} ${a.waktu} → ${a.teks}`).join('\n');
return reply(`❌ Tidak ada pengingat jam *${parsed.jam} ${parsed.waktu}* di grup *${grup}*.\n\n📋 Yang ada:\n${list || '(kosong)'}`);
}

const item = db.absen[idx];
if (item.media && fs.existsSync(item.media)) {
try { fs.unlinkSync(item.media); } catch {}
}
db.absen.splice(idx, 1);
writeDB(db);
reply(`✅ Pengingat jam *${parsed.jam} ${parsed.waktu}* grup *${grup}* berhasil DIHAPUS PERMANEN.\n\n📝 Teks yang dihapus: "${item.teks}"`);
}
break;

//━━━━━━━━━━━━━━━[ SET NOTIF JUMAT ]━━━━━━━━━━━━━━━\\
case 'setjumat': case 'addjumat': {
if (!isPrivate) return reply('⚠️ Fitur ini hanya bisa di private chat.');
if (!isCreator) return reply('❌ Fitur ini khusus Owner.');
if (!text) return reply(`Format:\n${prefix}setjumat idgrup|jam WIB|teks\n\nContoh:\n${prefix}setjumat 123@g.us|11:30 WIB|Sholat Jumat!`);

const parts = text.split('|').map(s => s.trim());
if (parts.length < 3) return reply(`❌ Format salah!\n\nGunakan:\n${prefix + command} idgrup|jam WIB|teks`);

const grup = parts[0];
const jamWaktuRaw = parts[1];
const teksRaw = parts.slice(2).join('|').trim();

if (!grup.endsWith('@g.us')) return reply('❌ ID grup harus diakhiri *@g.us*.');

const parsed = parseJamWaktu(jamWaktuRaw);
if (!parsed) return reply(`❌ Format jam salah!\nContoh: *11:30 WIB*`);

const flags = extractFlags(teksRaw);
if (!flags.cleanText) return reply('❌ Teks tidak boleh kosong.');

const db = readDB();
if (db.jumat.find(j => j.grup === grup)) {
return reply(`⚠️ Grup ini sudah punya notif Jumat.\n\nGunakan *${prefix}deljumat ${grup}* dulu kalau mau ganti.`);
}

try {
const meta = await RizzPiw.groupMetadata(grup);
if (!meta) return reply('❌ Bot tidak ada di grup tersebut atau ID salah.');
} catch {
return reply('❌ Gagal akses grup.');
}

let mediaPath = null;
let mediaMime = null;

const mediaInfo = getMediaSource(m, mime);
if (mediaInfo.source) {
await reply('📥 Mengunduh media...');
try {
const buffer = await RizzPiw.downloadMediaMessage(mediaInfo.source);
const ext = getExtFromMime(mediaInfo.mime);
const filename = `${grup.replace(/[^0-9]/g, '')}_jumat_${Date.now()}.${ext}`;
mediaPath = path.join(MEDIA_DIR, filename);
fs.writeFileSync(mediaPath, buffer);
mediaMime = mediaInfo.mime;
} catch (e) {
console.error(e);
return reply(`❌ Gagal download media: ${e.message}`);
}
}

db.jumat.push({
grup,
jam: parsed.jam,
waktu: parsed.waktu,
teks: flags.cleanText,
media: mediaPath,
mimetype: mediaMime,
noMention: flags.noMention,
status: 'on',
createdAt: new Date().toISOString(),
dayKey: null,
lastSentAt: null,
lastSentAtMs: null
});
writeDB(db);

let grupName = grup;
try { grupName = (await RizzPiw.groupMetadata(grup)).subject; } catch {}

reply(`✅ *Notif Jumat berhasil dibuat!*

📌 Grup : ${grupName}
🆔 ID : ${grup}
🕌 Hari : Setiap Jumat
⏰ Jam : ${parsed.jam} ${parsed.waktu}
📝 Teks : ${flags.cleanText}
${mediaPath ? '🖼️ Media : Ada ✔️' : '🖼️ Media : Tidak ada'}
${flags.noMention ? '🔕 Mention : OFF' : '🔔 Mention : ON'}`);
}
break;

//━━━━━━━━━━━━━━━[ HAPUS NOTIF JUMAT ]━━━━━━━━━━━━━━━\\
case 'deljumat': case 'hapusjumat': {
if (!isPrivate) return reply('⚠️ Fitur ini hanya bisa di private chat.');
if (!isCreator) return reply('❌ Fitur ini khusus Owner.');
if (!text) return reply(`Format:\n${prefix + command} idgrup`);

const grup = text.trim().split('|')[0].trim();
if (!grup.endsWith('@g.us')) return reply('❌ ID grup harus diakhiri *@g.us*.');

const db = readDB();
const idx = db.jumat.findIndex(j => j.grup === grup);
if (idx === -1) return reply(`❌ Tidak ada notif Jumat di grup *${grup}*.`);

const item = db.jumat[idx];
if (item.media && fs.existsSync(item.media)) {
try { fs.unlinkSync(item.media); } catch {}
}
db.jumat.splice(idx, 1);
writeDB(db);

reply(`✅ Notif Jumat grup *${grup}* berhasil dihapus.`);
}
break;

//━━━━━━━━━━━━━━━[ LIST ABSEN ]━━━━━━━━━━━━━━━\\
case 'listabsen': {
if (!isPrivate) return reply('⚠️ Fitur ini hanya bisa di private chat.');
if (!isCreator) return reply('❌ Fitur ini khusus Owner.');

const db = readDB();
if (db.absen.length === 0 && db.jumat.length === 0) {
return reply('📭 Belum ada pengingat yang dibuat.');
}

let teks = `「 *LIST PENGINGAT* 」\n\n`;

if (db.absen.length > 0) {
const grouped = {};
for (const item of db.absen) {
if (!grouped[item.grup]) grouped[item.grup] = [];
grouped[item.grup].push(item);
}

let grupNo = 0;
for (const [grup, items] of Object.entries(grouped)) {
grupNo++;
let grupName = grup;
try { grupName = (await RizzPiw.groupMetadata(grup)).subject; } catch {}

items.sort((a, b) => a.jam.localeCompare(b.jam));

teks += `*${grupNo}. ${grupName}*\n`;
teks += ` 🆔 ${grup}\n\n`;

for (let i = 0; i < items.length; i++) {
const item = items[i];
teks += `${i + 1}. ${item.status === 'off' ? '⛔' : '✅'} *${item.jam} ${item.waktu}*\n`;
teks += ` 📝 ${item.teks}\n`;
teks += ` 🖼️ Media: ${item.media && fs.existsSync(item.media) ? 'Ada ✔️' : '-'} • 🔔 Mention: ${item.noMention ? 'OFF' : 'ON'}\n\n`;
}
}
teks += `Total: *${db.absen.length}* pengingat dari *${Object.keys(grouped).length}* grup\n`;
}

if (db.jumat.length > 0) {
teks += `\n━━━ *NOTIF JUMAT* ━━━\n\n`;
for (let i = 0; i < db.jumat.length; i++) {
const j = db.jumat[i];
let grupName = j.grup;
try { grupName = (await RizzPiw.groupMetadata(j.grup)).subject; } catch {}
teks += `🕌 *${grupName}*\n`;
teks += ` 🆔 ${j.grup}\n`;
teks += ` ⏰ ${j.jam} ${j.waktu}\n`;
teks += ` 📝 ${j.teks}\n`;
teks += ` 🔘 ${j.status === 'off' ? 'OFF ❌' : 'ON ✅'}\n\n`;
}
teks += `Total Jumat: *${db.jumat.length}* grup`;
}

reply(teks);
}
break;

//━━━━━━━━━━━━━━━[ STATISTIK ]━━━━━━━━━━━━━━━\\
case 'statabsen': {
if (!isCreator) return reply('❌ Fitur ini khusus Owner.');
const db = readDB();
const total = db.absen.length;
const on = db.absen.filter(a => a.status !== 'off').length;
const off = total - on;
const withMedia = db.absen.filter(a => a.media && fs.existsSync(a.media)).length;
const noMention = db.absen.filter(a => a.noMention).length;
const grupUniq = new Set(db.absen.map(a => a.grup)).size;

reply(`「 *STATISTIK PENGINGAT* 」

📊 Total Pengingat : ${total}
🏘️ Total Grup: ${grupUniq}
✅ Aktif : ${on}
⛔ Nonaktif: ${off}
🖼️ Pakai Media : ${withMedia}
🔕 No Mention: ${noMention}

🕌 Notif Jumat : ${db.jumat.length} grup
💾 Media Dir : ${MEDIA_DIR}`);
}
break;

//━━━━━━━━━━━━━━━[ TEST ]━━━━━━━━━━━━━━━\\
case 'testabsen': {
if (!isPrivate) return reply('⚠️ Fitur ini hanya bisa di private chat.');
if (!isCreator) return reply('❌ Fitur ini khusus Owner.');
if (!text) return reply(`Format:\n${prefix + command} idgrup|jam`);

const parts = text.trim().split('|').map(s => s.trim());
const grup = parts[0];

if (!grup.endsWith('@g.us')) return reply('❌ ID grup harus diakhiri *@g.us*.');

const parsed = parseJamWaktu(parts[1]);
if (!parsed) return reply('❌ Format jam salah! Contoh: `testabsen 123@g.us|08:00 WIB`');

const db = readDB();
const item = db.absen.find(a => a.grup === grup && a.jam === parsed.jam && a.waktu === parsed.waktu);
if (!item) return reply(`❌ Tidak ada pengingat jam *${parsed.jam} ${parsed.waktu}* di grup *${grup}*.`);

try {
await sendAbsen(RizzPiw, item);
reply(`✅ Test kirim jam *${parsed.jam} ${parsed.waktu}* ke *${grup}* berhasil.`);
} catch (e) {
reply(`❌ Gagal test kirim: ${e.message}`);
}
}
break;

default:
break;
}

} catch (err) {
const e = String(err);
const ignoredErrors = [
'conflict', 'Cannot derive from empty media key', 'not-authorized',
'rate-overlimit', 'not-acceptable', 'Connection Closed', 'Timed Out',
'Session error', 'Value not found', 'Socket connection timeout',
'Bad MAC', 'Bad Request'
];
const shouldIgnore = ignoredErrors.some(error => e.includes(error));
if (!shouldIgnore) console.log(util.format(err));
}
}

//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\\
// AUTO RELOAD
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
});