require('./settings');
const fs = require('fs');
const pino = require('pino');
const path = require('path');
const chalk = require('chalk');
const cfonts = require('cfonts');
const figlet = require('figlet');
const readline = require('readline');
const FileType = require('file-type');
const yargs = require('yargs/yargs');
const _ = require('lodash');
const { color } = require('./lib/color');
const { Boom } = require('@hapi/boom');
const NodeCache = require('node-cache');
const PhoneNumber = require('awesome-phonenumber');

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  makeInMemoryStore,
  makeCacheableSignalKeyStore,
  proto,
  jidDecode,
  downloadContentFromMessage,
  generateWAMessageFromContent,
  generateForwardMessageContent,
} = require('@whiskeysockets/baileys');

const {
  imageToWebp,
  videoToWebp,
  writeExifImg,
  writeExifVid,
} = require('./lib/exif');

const {
  smsg,
  isUrl,
  getBuffer,
  getSizeMedia,
  sleep,
} = require('./lib/functions');

// Converter audio (opsional, dipakai sendFile)
let toAudio = null;
let toPTT = null;
try {
  ({ toAudio, toPTT } = require('./lib/converter'));
} catch (e) {
  // lib/converter tidak ada, audio dikirim sebagai dokumen
}

// Pairing code
const usePairingCode = true;
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
const question = (text) =>
  new Promise((resolve) => rl.question(text, resolve));

// Store
const store = makeInMemoryStore({
  logger: pino({ level: 'silent' }).child({
    level: 'silent',
    stream: 'store',
  }),
});

// Database
let low;

try {
  low = require('lowdb');
} catch (e) {
  low = require('./lib/lowdb');
}

const { Low, JSONFile } = low;
const mongoDB = require('./lib/mongoDB');

const opts = yargs(process.argv.slice(2))
  .exitProcess(false)
  .parse();

let db;

if (/mongodb/i.test(opts.db || '')) {
  db = new Low(new mongoDB(opts.db));
} else {
  db = new Low(
    new JSONFile(
      `${opts._[0] ? opts._[0] + '_' : ''}database.json`
    )
  );
}

global.db = db;
global.DATABASE = db;

global.loadDatabase = async function loadDatabase() {
  if (db.READ) {
    return new Promise((resolve) => {
      const interval = setInterval(() => {
        if (!db.READ) {
          clearInterval(interval);
          resolve(db.data == null ? loadDatabase() : db.data);
        }
      }, 1000);
    });
  }

  if (db.data !== null) return db.data;

  db.READ = true;

  try {
    await db.read();
  } finally {
    db.READ = false;
  }

  db.data = {
    users: {},
    chats: {},
    settings: {},
    ...(db.data || {}),
  };

  db.chain = _.chain(db.data);
  return db.data;
};

loadDatabase().catch(console.error);

// Auto-save database setiap 30 detik
if (!opts.test) {
  setInterval(async () => {
    if (global.db?.data) {
      try {
        await global.db.write();
      } catch (err) {
        console.error('Gagal menyimpan database:', err.message);
      }
    }
  }, 30 * 1000);
}

// Reconnect
let reconnectAttempts = 0;
const MAX_RECONNECT_DELAY = 60000;
let isStarting = false;

async function RizzXPiwStart() {
  if (isStarting) return;
  isStarting = true;

  try {
    const { state, saveCreds } =
      await useMultiFileAuthState('session');

    const msgRetryCounterCache = new NodeCache({
      stdTTL: 0,
      checkperiod: 0,
    });

    const RizzPiw = makeWASocket({
      logger: pino({ level: 'silent' }),
      printQRInTerminal: !usePairingCode,
      auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(
          state.keys,
          pino({ level: 'silent' })
        ),
      },
      msgRetryCounterCache,
      syncFullHistory: false,
      markOnlineOnConnect: true,
      connectTimeoutMs: 60000,
      defaultQueryTimeoutMs: 0,
      keepAliveIntervalMs: 10000,
      emitOwnEvents: true,
      fireInitQueries: true,
      generateHighQualityLinkPreview: true,
      browser: ['Ubuntu', 'Chrome', '20.0.04'],
      retryRequestDelayMs: 2000,
      maxMsgRetryCount: 5,
    });

    store.bind(RizzPiw.ev);

    console.log(
      color(
        figlet.textSync('RizzPiw', {
          font: 'Standard',
          horizontalLayout: 'default',
          verticalLayout: 'default',
          width: 80,
          whitespaceBreak: false,
        }),
        'cyan'
      )
    );

    if (usePairingCode && !RizzPiw.authState.creds.registered) {
      let phoneNumber = await question(
        chalk.cyan('Masukkan nomor WhatsApp dengan kode negara:\n')
      );

      phoneNumber = phoneNumber.replace(/[^0-9]/g, '');

      while (
        phoneNumber.length < 6 ||
        !/^[0-9]+$/.test(phoneNumber)
      ) {
        console.log('Contoh nomor: 628xxxxxxxxxx');

        phoneNumber = await question(
          'Masukkan nomor WhatsApp lagi:\n'
        );

        phoneNumber = phoneNumber.replace(/[^0-9]/g, '');
      }

      try {
        let code = await RizzPiw.requestPairingCode(phoneNumber, 'ZHEEREXX');

        code = code?.match(/.{1,4}/g)?.join('-') || code;

        console.log('Kode pairing WhatsApp:', code);
      } finally {
        rl.close();
      }
    }

    RizzPiw.decodeJid = (jid) => {
      if (!jid) return jid;

      if (/:\d+@/gi.test(jid)) {
        const decode = jidDecode(jid) || {};

        return (
          (decode.user &&
            decode.server &&
            decode.user + '@' + decode.server) ||
          jid
        );
      }

      return jid;
    };

    // Pesan masuk
    RizzPiw.ev.on('messages.upsert', async (chatUpdate) => {
      try {
        if (chatUpdate.type !== 'notify') return;

        const mek = chatUpdate.messages[0];

        if (!mek?.message) return;

        mek.message =
          Object.keys(mek.message)[0] === 'ephemeralMessage'
            ? mek.message.ephemeralMessage.message
            : mek.message;

        if (mek.key?.remoteJid === 'status@broadcast') return;
        if (!RizzPiw.public && !mek.key.fromMe) return;

        if (mek.key?.id?.startsWith('BAE5')) return;

        const m = smsg(RizzPiw, mek, store);

        const handlerPath = require.resolve('./rizzpiw');

        delete require.cache[handlerPath];

        require(handlerPath)(
          RizzPiw,
          m,
          chatUpdate,
          store
        );
      } catch (err) {
        const ignoredErrors = [
          'bad-request',
          'badSession',
          'conflict',
          'not-authorized',
        ];

        if (
          ignoredErrors.some(
            (e) => err.message && err.message.includes(e)
          )
        ) {
          return;
        }

        console.error('Unhandled message error:', err);
      }
    });


    // Mendapatkan nama kontak
    RizzPiw.getName = (jid, withoutContact = false) => {
      const id = RizzPiw.decodeJid(jid);

      withoutContact =
        RizzPiw.withoutContact || withoutContact;

      let v;

      if (id.endsWith('@g.us')) {
        return new Promise(async (resolve) => {
          v = store.contacts[id] || {};

          if (!(v.name || v.subject)) {
            try {
              v = await RizzPiw.groupMetadata(id);
            } catch {
              v = {};
            }
          }

          resolve(v.name || v.subject || id);
        });
      }

      v =
        id === '0@s.whatsapp.net'
          ? { id, name: 'WhatsApp' }
          : id === RizzPiw.decodeJid(RizzPiw.user?.id)
            ? RizzPiw.user
            : store.contacts[id] || {};

      return (
        (withoutContact ? '' : v.name) ||
        v.subject ||
        v.verifiedName ||
        id
      );
    };

    // Mengirim kontak
    RizzPiw.sendContact = async (
      jid,
      kon,
      quoted = '',
      opts = {}
    ) => {
      const list = [];

      for (const i of kon) {
        const name = await RizzPiw.getName(
          i + '@s.whatsapp.net'
        );

        list.push({
          displayName: name,
          vcard:
            `BEGIN:VCARD\nVERSION:3.0\n` +
            `FN:${name}\n` +
            `TEL;type=CELL;type=VOICE;waid=${i}:${i}\n` +
            'END:VCARD',
        });
      }

      return RizzPiw.sendMessage(
        jid,
        {
          contacts: {
            displayName: `${list.length} Kontak`,
            contacts: list,
          },
          ...opts,
        },
        { quoted }
      );
    };

    // true = bot bisa dipakai semua orang
    // false = mode self
    RizzPiw.public = true;

    RizzPiw.ev.on('creds.update', saveCreds);

    // Download media pesan
    RizzPiw.downloadMediaMessage = async (message) => {
      const mime =
        (message.msg || message).mimetype || '';

      const messageType = message.mtype
        ? message.mtype.replace(/Message/gi, '')
        : mime.split('/')[0];

      const stream = await downloadContentFromMessage(
        message,
        messageType
      );

      let buffer = Buffer.from([]);

      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }

      return buffer;
    };

    // Kirim gambar
    RizzPiw.sendImage = async (
      jid,
      input,
      caption = '',
      quoted = '',
      options = {}
    ) => {
      let buffer;

      if (Buffer.isBuffer(input)) {
        buffer = input;
      } else if (
        /^data:.*?\/.*?;base64,/i.test(input)
      ) {
        buffer = Buffer.from(
          input.split(',')[1],
          'base64'
        );
      } else if (/^https?:\/\//.test(input)) {
        buffer = await getBuffer(input);
      } else if (fs.existsSync(input)) {
        buffer = fs.readFileSync(input);
      } else {
        throw new Error('File gambar tidak ditemukan');
      }

      return RizzPiw.sendMessage(
        jid,
        {
          image: buffer,
          caption,
          ...options,
        },
        { quoted }
      );
    };

    RizzPiw.sendText = (
      jid,
      text,
      quoted = '',
      options = {}
    ) => {
      return RizzPiw.sendMessage(
        jid,
        { text, ...options },
        { quoted }
      );
    };

    RizzPiw.sendTextWithMentions = async (
      jid,
      text,
      quoted,
      options = {}
    ) => {
      const mentionedJid = [
        ...text.matchAll(/@(\d{5,16})/g),
      ].map((v) => v[1] + '@s.whatsapp.net');

      return RizzPiw.sendMessage(
        jid,
        {
          text,
          contextInfo: { mentionedJid },
          ...options,
        },
        { quoted }
      );
    };

    RizzPiw.sendTextMentions = async (
      jid,
      teks,
      mention,
      quoted = ''
    ) => {
      return RizzPiw.sendMessage(
        jid,
        { text: teks, mentions: mention },
        { quoted }
      );
    };

    // Kirim gambar sebagai stiker
    RizzPiw.sendImageAsSticker = async (
      jid,
      input,
      quoted,
      options = {}
    ) => {
      let buff = Buffer.isBuffer(input)
        ? input
        : fs.existsSync(input)
          ? fs.readFileSync(input)
          : await getBuffer(input);

      const buffer =
        options.packname || options.author
          ? await writeExifImg(buff, options)
          : await imageToWebp(buff);

      await RizzPiw.sendMessage(
        jid,
        { sticker: { url: buffer } },
        { quoted }
      );

      return buffer;
    };

    RizzPiw.sendVideoAsSticker = async (
      jid,
      input,
      quoted,
      options = {}
    ) => {
      let buff = Buffer.isBuffer(input)
        ? input
        : fs.existsSync(input)
          ? fs.readFileSync(input)
          : await getBuffer(input);

      const buffer =
        options.packname || options.author
          ? await writeExifVid(buff, options)
          : await videoToWebp(buff);

      await RizzPiw.sendMessage(
        jid,
        { sticker: { url: buffer } },
        { quoted }
      );

      return buffer;
    };

    // Polling
    RizzPiw.sendPoll = (
      jid,
      name = '',
      values = [],
      selectableCount = 0
    ) => {
      return RizzPiw.sendMessage(jid, {
        poll: {
          name,
          values,
          selectableCount,
        },
      });
    };

    // Simpan media
    RizzPiw.downloadAndSaveMediaMessage = async (
      message,
      filename,
      attachExtension = true
    ) => {
      const quoted = message.msg
        ? message.msg
        : message;

      const mime = quoted.mimetype || '';

      const messageType = message.mtype
        ? message.mtype.replace(/Message/gi, '')
        : mime.split('/')[0];

      const stream = await downloadContentFromMessage(
        quoted,
        messageType
      );

      let buffer = Buffer.from([]);

      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }

      const type = await FileType.fromBuffer(buffer);

      const trueFileName = attachExtension
        ? `${filename}.${type?.ext || 'bin'}`
        : filename;

      fs.writeFileSync(trueFileName, buffer);

      return trueFileName;
    };

    // Modifikasi salinan pesan
    RizzPiw.cMod = (
      jid,
      copy,
      text = '',
      sender = RizzPiw.user?.id,
      options = {}
    ) => {
      const mtype = Object.keys(copy.message)[0];
      const msg =
        mtype === 'ephemeralMessage'
          ? copy.message.ephemeralMessage.message
          : copy.message;

      const actualType =
        mtype === 'ephemeralMessage'
          ? Object.keys(msg)[0]
          : mtype;

      const content = msg[actualType];

      if (typeof content === 'string') {
        msg[actualType] = text || content;
      } else if (content?.caption) {
        content.caption = text || content.caption;
      } else if (content?.text) {
        content.text = text || content.text;
      }

      if (typeof content !== 'string') {
        msg[actualType] = { ...content, ...options };
      }

      if (copy.key.participant) {
        sender = copy.key.participant =
          sender || copy.key.participant;
      }

      copy.key.remoteJid = jid;
      copy.key.fromMe = sender === RizzPiw.user?.id;

      return proto.WebMessageInfo.fromObject(copy);
    };

    // Parsing mention
    RizzPiw.parseMention = async (text) => {
      return [
        ...text.matchAll(/@([0-9]{5,16}|0)/g),
      ].map((v) => v[1] + '@s.whatsapp.net');
    };

    // Reaksi pesan
    RizzPiw.sendReact = async (
      jid,
      emoticon,
      keys = {}
    ) => {
      return RizzPiw.sendMessage(jid, {
        react: {
          text: emoticon,
          key: keys,
        },
      });
    };

    RizzPiw.getFile = async (PATH, save) => {
      let res;
      let filename;

      const data = Buffer.isBuffer(PATH)
        ? PATH
        : /^data:.*?\/.*?;base64,/i.test(PATH)
          ? Buffer.from(PATH.split`,`[1], 'base64')
          : /^https?:\/\//.test(PATH)
            ? await (res = await getBuffer(PATH))
            : fs.existsSync(PATH)
              ? ((filename = PATH), fs.readFileSync(PATH))
              : typeof PATH === 'string'
                ? PATH
                : Buffer.alloc(0);

      const type =
        (await FileType.fromBuffer(data)) || {
          mime: 'application/octet-stream',
          ext: '.bin',
        };

      filename = path.join(__filename, '../src/' + new Date() * 1 + '.' + type.ext);

      if (data && save) fs.promises.writeFile(filename, data);

      return {
        res,
        filename,
        size: await getSizeMedia(data),
        ...type,
        data,
      };
    };

    RizzPiw.sendFile = async (
      jid,
      PATH,
      filename = '',
      caption = '',
      quoted,
      ptt = false,
      options = {}
    ) => {
      const type = await RizzPiw.getFile(PATH, true);
      let { res, data: file, filename: pathFile } = type;

      if ((res && res.status !== 200) || file.length <= 65536) {
        try {
          throw { json: JSON.parse(file.toString()) };
        } catch (e) {
          if (e.json) throw e.json;
        }
      }

      const opt = { filename };
      if (quoted) opt.quoted = quoted;
      if (!type) options.asDocument = true;

      let mtype = '';
      let mimetype = type.mime;

      if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) {
        mtype = 'sticker';
      } else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) {
        mtype = 'image';
      } else if (/video/.test(type.mime)) {
        mtype = 'video';
      } else if (/audio/.test(type.mime)) {
        const convert = ptt ? toPTT : toAudio;

        if (convert) {
          const converted = await convert(file, type.ext);
          file = converted.data;
          pathFile = converted.filename;
          mimetype = 'audio/ogg; codecs=opus';
        }

        mtype = 'audio';
      } else {
        mtype = 'document';
      }

      if (options.asDocument) mtype = 'document';

      const message = {
        ...options,
        caption,
        ptt,
        [mtype]: { url: pathFile },
        mimetype,
      };

      let m;
      try {
        m = await RizzPiw.sendMessage(jid, message, { ...opt, ...options });
      } catch (e) {
        console.error(e);
        m = null;
      } finally {
        if (!m) {
          m = await RizzPiw.sendMessage(
            jid,
            { ...message, [mtype]: file },
            { ...opt, ...options }
          );
        }
      }

      return m;
    };

    RizzPiw.copyNForward = async (
      jid,
      message,
      forceForward = false,
      options = {}
    ) => {
      let vtype;

      if (options.readViewOnce) {
        message.message =
          message.message?.ephemeralMessage?.message ||
          message.message ||
          undefined;

        vtype = Object.keys(message.message.viewOnceMessage.message)[0];

        delete (message.message?.ignore
          ? message.message.ignore
          : message.message || undefined);

        delete message.message.viewOnceMessage.message[vtype].viewOnce;

        message.message = {
          ...message.message.viewOnceMessage.message,
        };
      }

      const mtype = Object.keys(message.message)[0];
      const content = await generateForwardMessageContent(message, forceForward);
      const ctype = Object.keys(content)[0];

      let context = {};
      if (mtype !== 'conversation') {
        context = message.message[mtype].contextInfo;
      }

      content[ctype].contextInfo = {
        ...context,
        ...content[ctype].contextInfo,
      };

      const waMessage = await generateWAMessageFromContent(
        jid,
        content,
        options
          ? {
              ...content[ctype],
              ...options,
              ...(options.contextInfo
                ? {
                    contextInfo: {
                      ...content[ctype].contextInfo,
                      ...options.contextInfo,
                    },
                  }
                : {}),
            }
          : {}
      );

      await RizzPiw.relayMessage(jid, waMessage.message, {
        messageId: waMessage.key.id,
      });

      return waMessage;
    };

    RizzPiw.serializeM = (m) => smsg(RizzPiw, m, store);

    // Status koneksi dan reconnect
    RizzPiw.ev.on('connection.update', async (update) => {
      const { connection, lastDisconnect } = update;

      if (connection === 'connecting') {
        console.log('⟳ Menghubungkan ke WhatsApp...');
      }

      if (connection === 'open') {
        reconnectAttempts = 0;
        console.log(
          '✓ Terhubung sebagai:',
          RizzPiw.user?.name || 'Bot'
        );
      }

      if (connection === 'close') {
        const statusCode =
          lastDisconnect?.error?.output?.statusCode;

        console.log(
          '✗ Koneksi terputus. Kode:',
          statusCode
        );

        if (
          statusCode === DisconnectReason.loggedOut ||
          statusCode === 401
        ) {
          console.log(
            'Session logout. Pairing ulang diperlukan.'
          );
          process.exit(0);
        }

        if (statusCode === 403) {
          console.log(
            'Koneksi ditolak WhatsApp. Periksa status akun.'
          );
          process.exit(0);
        }

        reconnectAttempts++;

        const delay = Math.min(
          5000 * Math.pow(1.5, reconnectAttempts - 1),
          MAX_RECONNECT_DELAY
        );

        console.log(
          `⟳ Reconnect ke-${reconnectAttempts} dalam ` +
          `${Math.round(delay / 1000)} detik...`
        );

        setTimeout(() => {
          isStarting = false;

          RizzXPiwStart().catch((err) => {
            console.error('Gagal reconnect:', err.message);
          });
        }, delay);
      }
    });

    // Kontak diperbarui
    RizzPiw.ev.on('contacts.update', (update) => {
      for (const contact of update) {
        const id = RizzPiw.decodeJid(contact.id);

        if (store?.contacts) {
          store.contacts[id] = {
            id,
            name: contact.notify,
          };
        }
      }
    });

    return RizzPiw;
  } catch (err) {
    console.error('Gagal menjalankan bot:', err);

    setTimeout(() => {
      isStarting = false;

      RizzXPiwStart().catch(console.error);
    }, 5000);
  } finally {
    isStarting = false;
  }
}

RizzXPiwStart().catch((err) => {
  console.error('Error pertama kali start:', err);
});

const file = require.resolve(__filename);

fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log('File index.js berubah, memuat ulang...');
  delete require.cache[file];
  require(file);
});