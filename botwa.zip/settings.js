const fs = require('fs')
const chalk = require('chalk')

//—————「 Set Untuk Owner 」—————//

global.ownerName = 'Asep Yusup' // Isi Nama Owner
global.botName = 'Bot_Absen' // Isi Nama Bot

global.owner = ['6283192698049','6285772148224','6285717227600'] // Isi Nomor Lu
global.ownerNumber = ["6285772148224@s.whatsapp.net"] // Isi Nomor lu
global.nomorOwner = "6285772148224" //Isi Nomor Lu

//—————「 Set Lain Nya 」—————//

global.MAX_PENGINGAT = 10; // maks 10 pengingat per grup

global.author = 'RizzPiw'
global.email = 'Piw@gmail.com'
global.youtube = 'https://www.youtube.com/@RizzPiw2'
global.region = 'I`m From Indonesia'
global.prefa = ['','!','.','#','-','•']
global.tempatDB = 'database.json'

global.mess = {
success: 'Succes',
admin: 'Fitur Khusus Admin Group',
botAdmin: 'Bot Harus Menjadi Admin Terlebih Dahulu',
owner: 'Fitur Khusus Owner Bot',
group: 'Fitur Digunakan Hanya Untuk Group',
private: 'Fitur Digunakan Hanya Untuk Private Chat',
bot: 'Fitur Khusus Pengguna Nomor Bot',
error: 'Mungkin Lagi Error Kak Harap Lapor Owner Biar Langsung Di Benerin',
wait: 'Tunggu Sebentar'
}

//~~~~~~~~~~~~~~~< PROCESS >~~~~~~~~~~~~~~~\\

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});